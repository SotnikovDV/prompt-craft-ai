<?php

namespace App\Services;

use App\Models\Problem;
use App\Models\Clinic;
use App\Models\Doctor;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class PerplexityService
{
    protected string $apiKey;
    protected string $baseUrl = 'https://api.perplexity.ai/chat/completions'; // endpoint
    protected int $timeout = 60; // увеличиваем таймаут до 60 секунд
    protected int $retryAttempts = 3; // количество попыток

    //Конструктор
    public function __construct()
    {
        $this->apiKey = config('services.perplexity.api_key');
    }
    //Подготовка текста для передачи в AI
    private function preprocessText(string $text): string
    {
        // Удаление лишних пробелов, символов и т.д.
        $text = preg_replace('/\s+/', ' ', $text);
        $text = trim($text);

        return $text;
    }
    // Получаем описание медикамента
    public function getMedicDescription(string $medicamentName): ?string
    {

        //$apiKey = config('services.perplexity.api_key');

        //$url = 'https://api.perplexity.ai/chat/completions'; //

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Content-Type' => 'application/json',
        ])->post($this->baseUrl, [
            'model' => 'sonar',
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'Ты эксперт-провизор в фармакологии.'
                ],
                [
                    'role' => 'user',
                    'content' => "Дай краткое (не более 950 символов) описание медикамента: {$medicamentName}"
                ]
            ],
            'max_tokens' => 950,
            'temperature' => 0.3,
        ]);

        if ($response->successful()) {
            //
            $result = $response->json();
            return $result['choices'][0]['message']['content'] ?? null;
        }
        return null;
    }

    // Получить структурированную информацию о медикаменте по наименованиюиз Perplexity
    public function getMedicamentInfo(string $medicamentName): ?array
    {
        $schema = [
            "type" => "object",
            "properties" => [
                "Торговое наименование" => ["type" => "string"],
                "Действующее вещество" => ["type" => "string"],
                "Цифровой трехзначный код страны происхождения" => ["type" => "string"],
                "Аналоги" => [
                    "type" => "array",
                    "items" => ["type" => "string"]
                ],
                "Краткое описание" => ["type" => "string"],
                "Способ приема" => ["type" => "string"],
            ],
            "required" => [
                "Торговое наименование",
                "Действующее вещество",
                "Цифровой трехзначный код страны происхождения",
                "Аналоги",
                "Краткое описание",
                "Способ приема"
            ]
        ];

        //$apiKey = config('services.perplexity.api_key');

        //$baseUrl = 'https://api.perplexity.ai/chat/completions'; // endpoint

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Content-Type' => 'application/json',
        ])->post($this->baseUrl, [
            'model' => 'sonar', // или другой, если требуется
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'Ты эксперт-провизор в фармакологии. Отвечай только на русском языке.'
                ],
                [
                    'role' => 'user',
                    'content' => "Дай структурированную информацию о лекарстве «{$medicamentName}». Верни результат строго в формате JSON с полями: Торговое наименование, Действующее вещество, Цифровой трехзначный код страны происхождения, Аналоги, Краткое описание, Способ приема"
                ]
            ],
            'response_format' => [
                    'type' => 'json_schema',
                    'json_schema' => ['schema' => $schema]
            ],
            'max_tokens' => 950,
            'temperature' => 0.3,
        ]);

        if ($response->successful()) {
            //
            $content = $response->json('choices.0.message.content');
            return json_decode($content, true);
        }
        return null;
    }
    // Получить структурированную информацию о стране происхождения по цифровому трехзначному коду из Perplexity
    public function getCountryInfo(string $countryCode): ?array
    {
        $schema = [
            "type" => "object",
            "properties" => [
                "Цифровой трехзначный код страны" => ["type" => "string"],
                "Название страны" => ["type" => "string"],
                "Двухбуквенный код страны" => ["type" => "string"],
            ],
            "required" => [
                "Цифровой трехзначный код страны",
                "Название страны",
                "Двухбуквенный код страны"
            ]
        ];

        //$apiKey = config('services.perplexity.api_key');

        //$url = 'https://api.perplexity.ai/chat/completions'; // endpoint

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Content-Type' => 'application/json',
        ])->post($this->baseUrl, [
            'model' => 'sonar', // или другой, если требуется
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'Отвечай только на русском языке.'
                ],
                [
                    'role' => 'user',
                    'content' => "Дай структурированную информацию о стране по цифровому трехзначному коду «{$countryCode}». Верни результат строго в формате JSON с полями: Цифровой трехзначный код страны, Название страны, Двухбуквенный код страны"
                ]
            ],
            'response_format' => [
                    'type' => 'json_schema',
                    'json_schema' => ['schema' => $schema]
            ],
            'max_tokens' => 950,
            'temperature' => 0.3,
        ]);

        if ($response->successful()) {
            //
            $content = $response->json('choices.0.message.content');
            return json_decode($content, true);
        }
        return null;
    }

    // Получить структурированную информацию о реквизитах документа по его содержимому из Perplexity
    public function getDocumentInfo(string $documentContent): ?array
    {
        $schema = [
            "type" => "object",
            "properties" => [
                "Тип документа" => [
                    "type" => "integer",
                    "description" => "Код типа документа согласно справочнику: 1 - Лабораторные анализы, 2 - Резюме осмотра, 4 - Страховка, 6 - Прочие документы, 7 - Функциональные исследования, 8 - Рецепт, 9 - Документация для разработки, 10 - Информация по заболеванию, 11 - Справка, 12 - Направления в клинику, 13 - Программы оздоровления"
                ],
                "Дата документа" => [
                    "type" => "string",
                    "format" => "date",
                    "description" => "Дата составления или выдачи документа в формате yyyy-MM-dd"
                ],
                "Описание документа" => [
                    "type" => "string",
                    "description" => "Краткое описание документа (максимум 1000 символов)",
                    "maxLength" => 1000
                ],
                "Резюме документа" => [
                    "type" => "string",
                    "description" => "Резюме результатов анализа, исследования или осмотра врачом (для других типов документов не надо)"
                ]
            ],
            "required" => [
                "Тип документа",
                "Дата документа",
                "Описание документа"
            ]
        ];

        $documentText = $this->preprocessText($documentContent);

        try {
            $response = Http::timeout($this->timeout)
                ->retry($this->retryAttempts, 3000) // 3 попытки с задержкой 3 секунды
                ->withHeaders([
                    'Authorization' => 'Bearer ' . $this->apiKey,
                    'Content-Type' => 'application/json',
                ])->post($this->baseUrl, [
                    //'model' => 'sonar', // самая простая, дешевая, но быстрая модель
                    'model' => 'sonar-pro',
                    //'model' => 'sonar-reasoning-pro', // самая подходящая для извлечения реквизитов документов из текста
                    'messages' => [
                        [
                            'role' => 'system',
                            'content' => 'Ты эксперт по извлечению ключевых реквизитов из документов. Твоя задача - тщательно проанализировать текст и извлечь из него ключевые данные согласно заданной схеме. Если какое-то поле не удается найти в тексте, укажи null вместо выдумывания данных.'
                        ],
                        [
                            'role' => 'user',
                            'content' => "Извлеки ключевые реквизиты из документа и верни их в формате JSON (" . json_encode($schema, JSON_UNESCAPED_UNICODE) . "):\n"
                                . "Текст документа: {$documentText}"
                        ]
                    ],
                    /* 'response_format' => [
                        'type' => 'json_schema',
                        'json_schema' => ['schema' => $schema]
                    ], */
                    'max_tokens' => 2000,
                    'temperature' => 0.1,  // минимизация галлюционирования модели
                ]);

            if ($response->successful()) {
                $content = $response->json('choices.0.message.content');
                return json_decode($content, true);
            }

            // Логируем ошибку
            Log::error('Perplexity API Error', [
                'status' => $response->status(),
                'body' => $response->body(),
                'document_content' => substr($documentContent, 0, 100) . '...' // Логируем только начало документа
            ]);

            return [
                'error' => true,
                'status' => $response->status(),
                'message' => 'Ошибка при обработке документа через Perplexity API'
            ];

        } catch (\Exception $e) {
            Log::error('Perplexity API Exception', [
                'message' => $e->getMessage(),
                'document_content' => substr($documentContent, 0, 100) . '...'
            ]);

            return [
                'error' => true,
                'message' => 'Произошла ошибка при обращении к Perplexity API: ' . $e->getMessage()
            ];
        }
    }

    // Получить структурированную информацию о реквизитах документа по его содержимому из Perplexity
    // для формирования записи визита в клинику
    public function getVisitInfo(string $documentContent): ?array
    {
        $pers_id = dh_data_person()->id;

        // получаем список проблем
        $problems = Problem::where('person', $pers_id)->get();
        $problem_list = $problems->map(function($problem) {
            return $problem->id . ' - ' . $problem->name;
        })->implode(', ');

        // получаем список клиник
        $clinics = Clinic::all();
        $clinic_list = $clinics->map(function($clinic) {
            return $clinic->id . ' - ' . $clinic->name;
        })->implode(', ');

        // получаем список врачей
        $doctors = Doctor::all();
        $doctor_list = $doctors->map(function($doctor) {
            return $doctor->id . ' - ' . $doctor->fio;
        })->implode(', ');

        // формируем схему для извлечения реквизитов
        $schema = [
            "type" => "object",
            "properties" => [
                "Дата визита" => [
                    "type" => "string",
                    "format" => "date",
                    "description" => "Дата визита в формате yyyy-MM-dd"
                ],
                "Проблема" => [
                    "type" => "string",
                    "description" => "Проблема согласно справочнику: " . $problem_list
                ],
                "Клиника" => [
                    "type" => "string",
                    "description" => "Клиника согласно справочнику: " . $clinic_list
                ],
                "Врач" => [
                    "type" => "string",
                    "description" => "Врач согласно справочнику: " . $doctor_list
                ],
                "Диагноз" => [
                    "type" => "string",
                    "description" => "Диагноз в формате ICD-10 + Словесное описание"
                ],
                "Лечение" => [
                    "type" => "string",
                    "description" => "Врачебные рекомендации (лечение, анализы, процедуры, дополнительные исследования)"
                ],
                "Назначение" => [
                    "type" => "string",
                    "description" => "Назначеные лекарственные средства"
                ],
                "Следующий визит" => [
                    "type" => "string",
                    "format" => "date",
                    "description" => "Дата следующего визита в формате yyyy-MM-dd"
                ],
                "Тип визита" => [
                    "type" => "string",
                    "description" => "Тип визита согласно справочнику: 1 - первичный, 2 - повторный"
                ],
            ],
            "required" => [
                "Дата визита",
                "Диагноз",
                "Лечение",
                "Назначение"
            ]
        ];

        //dd($schema);

        $documentText = $this->preprocessText($documentContent);

        try {
            $response = Http::timeout($this->timeout)
                ->retry($this->retryAttempts, 1000) // 3 попытки с задержкой 1 секунда
                ->withHeaders([
                    'Authorization' => 'Bearer ' . $this->apiKey,
                    'Content-Type' => 'application/json',
                ])->post($this->baseUrl, [
                    //'model' => 'sonar', // самая простая, дешевая, но быстрая модель
                    'model' => 'sonar-pro',
                    //'model' => 'sonar-reasoning-pro', // самая подходящая для извлечения реквизитов документов из текста
                    'messages' => [
                        [
                            'role' => 'system',
                            'content' => 'Ты эксперт по извлечению ключевых реквизитов из документов. Твоя задача - тщательно проанализировать текст результатов визита к врачу и извлечь из него ключевые данные согласно заданной схеме. Если какое-то поле не удается найти в тексте, укажи null вместо выдумывания данных.'
                        ],
                        [
                            'role' => 'user',
                            'content' => "Извлеки ключевые реквизиты из текста результатов визита к врачу и верни их в формате JSON (" . json_encode($schema, JSON_UNESCAPED_UNICODE) . "):\n"
                                . "Текст результатов визита: {$documentText}"
                        ]
                    ],
                    /* 'response_format' => [
                        'type' => 'json_schema',
                        'json_schema' => ['schema' => $schema]
                    ], */
                    'max_tokens' => 3000,
                    'temperature' => 0.1,  // минимизация галлюционирования модели
                ]);

            if ($response->successful()) {
                $content = $response->json('choices.0.message.content');
                return json_decode($content, true);
            }

            // Логируем ошибку
            Log::error('Perplexity API Error', [
                'status' => $response->status(),
                'body' => $response->body(),
                'document_content' => substr($documentContent, 0, 100) . '...' // Логируем только начало документа
            ]);

            return [
                'error' => true,
                'status' => $response->status(),
                'message' => 'Ошибка при обработке документа через Perplexity API'
            ];

        } catch (\Exception $e) {
            Log::error('Perplexity API Exception', [
                'message' => $e->getMessage(),
                'document_content' => substr($documentContent, 0, 100) . '...'
            ]);

            return [
                'error' => true,
                'message' => 'Произошла ошибка при обращении к Perplexity API: ' . $e->getMessage()
            ];
        }
    }
}
