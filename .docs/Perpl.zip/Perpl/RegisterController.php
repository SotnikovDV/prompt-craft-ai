<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class RegisterController extends Controller
{
    // переход на страницу регистрации  нового пользователя
    public function create(){
        // переходим на страницу регистрации
        return view('auth.register');
    }

    // Сохранение нового пользователя в БД
    public function store(Request $request){

        // проверка данных
        $request->validate([
            'name' => 'required|string',
            'email' => 'required|string|email|unique:users,email|max:255',
            'password' => 'required|confirmed|min:6'
        ]);

        // создаем пользователя в БД
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password)
        ]);

        // аутентифицируем
        Auth::login($user);

        // переходим на страницу аутентифицированных пользователей
        return redirect()->route('dashboard');
    }
}
