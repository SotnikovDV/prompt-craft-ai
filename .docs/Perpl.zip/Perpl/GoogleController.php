<?php

namespace App\Http\Controllers;

use Google\Client;
use Google\Service\Calendar;
use Google\Service\Oauth2;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\GoogleToken;
use App\Models\User;
use App\Models\Plan;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;

class GoogleController extends Controller
{
    // Создание Google Client
    private function createGoogleClient(): Client
    {
        $client = new Client();
        $client->setClientId(config('services.google.client_id'));
        $client->setClientSecret(config('services.google.client_secret'));
        $client->setRedirectUri(config('services.google.redirect'));
        $client->setAccessType('offline');
        //Это устарело ?? $client->setApprovalPrompt ('force');  //???
        $client->setPrompt('consent');
        $client->setScopes([
            Calendar::CALENDAR,
            Calendar::CALENDAR_EVENTS,
            Oauth2::USERINFO_PROFILE,
            Oauth2::USERINFO_EMAIL,
            Oauth2::OPENID,
        ]);
        $client->setIncludeGrantedScopes(true);  // ???
        return $client;
    }

    // Перенаправление на Google для авторизации
    public function redirectToGoogle()
    {
        // Сохраним источник вызова авторизации в соцсети (диалог входа, профиль)
        session(['google_auth_src' => ($_GET['src'] ?? null)]);

        //dd(env('GOOGLE_CLIENT_ID'), env('GOOGLE_CLIENT_SECRET'));

        $client = $this->createGoogleClient();
        //dd($client);

        $authUrl = $client->createAuthUrl();
        //$authUrl = $authUrl . '&prompt=consent';

        return redirect($authUrl);
    }

    // Обработка обратного вызова от Google
    public function handleGoogleCallback(Request $request)
    {
        $client = $this->createGoogleClient();

        if ($request->has('code')) {
            $token = $client->fetchAccessTokenWithAuthCode($request->input('code'));

            if (isset($token['error'])) {
                return redirect()->route('login.error')->withErrors(['warn-show' => $token['error']]);
            }

            // Устанавливаем токен в клиент
            //$client->setAccessToken($token['access_token']);
            $client->setAccessToken($token);

            // Проверяем, действительно ли токен установлен
            if (!$client->isAccessTokenExpired()) {

                // Получаем информацию о пользователе через Google People API
                $googleService = new Oauth2($client);
                $googleUser = $googleService->userinfo->get(); // Данные профиля пользователя Google

                // Поиск пользователя по email в базе данных
                //$user = User::where('email', $googleUser->email)->first();

                // Получаем источник вызова авторизации в соцсети из сессии
                $src = session('google_auth_src', null);

                if (empty($src)) {
                    // Авторизация/регистрация через соцсеть для входа на сайт
                    // используем firstOrCreate для проверки есть ли такие пользователи в нашей БД
                    $user = User::firstOrCreate([
                        'email' => $googleUser->email
                    ], [
                        'name' => $googleUser->name,
                        'password' => bcrypt(str()->random(16)), //Hash::make(Str::random(24)),  // Генерируем случайный пароль
                    ]);

                    Auth::login($user, true);

                    $redirect_url = session('url.intended', route('home'));

                } elseif ($src === 'prf') {
                    // Авторизация для связи аккаунта пользователя сайта и соцсети

                    $user = Auth::user();

                    $redirect_url = route('profile') . '#social';
                } else {
                    // прочие причины/источники авторизации ы соцсети

                    $user = Auth::user();

                    $redirect_url = route('home');
                }

                if (isset($user)) {
                    // Сохранение токена в базе данных
                    GoogleToken::updateOrCreate(
                        ['user_id' => $user->id], // Auth::id()],
                        [
                            'access_token' => $token['access_token'],
                            'refresh_token' => $token['refresh_token'] ?? null,
                            'expires_at' => now()->addSeconds($token['expires_in']),
                        ]
                    );

                    // Дополнительно сохраняем токен в старой структуре - в таблице users
                    $user->update([
                        'google_id' => $googleUser->id,
                        'google_token' => $googleUser->token,
                        'google_email' => $googleUser->email,
                    ]);
                }

                return redirect($redirect_url)->with('success', 'Успешная авторизация через Google!');

            } else {
                return redirect()->route('error.page')->withErrors(['warn-show' => 'Истек срок действия авторизации в Google. Авторизуйтесь по новой.']);
            }
        }

        return redirect()->route('login.error')->withErrors(['warn-show' => 'Ошибка авторизации в Google']);
    }

    // Добавление события в календарь
    public function addEventBase($title, $comment, $eventDateTime )   //(Request $request)
    {
        $redirect_url = session('url.intended', route('plans.index'));

        $userToken = GoogleToken::where('user_id', Auth::id())->first();

        if (!$userToken) {
            return redirect()->route('google')->withErrors(['warn-show' => 'Авторизуйтесь в Google']);
        }


        $client = $this->createGoogleClient();
        $client->setAccessToken($userToken->access_token);

        // Проверка истечения токена
        if ($client->isAccessTokenExpired()) {
            if ($userToken->refresh_token) {
                $newToken = $client->fetchAccessTokenWithRefreshToken($userToken->refresh_token);
                $userToken->update([
                    'access_token' => $newToken['access_token'],
                    'expires_at' => now()->addSeconds($newToken['expires_in']),
                ]);
            } else {
                return redirect()->route('google')->withErrors(['warn-show' => 'Истек срок действия токена авторизации в Google. Авторизуйтесь по новой!']);
            }
        }

        // Создание события
        $service = new Calendar($client);

        // Формирование дат события
        $startDateTime = Carbon::parse($eventDateTime)->format('Y-m-d\TH:i:sP'); // Начало события
        $endDateTime = Carbon::parse($eventDateTime)->addHour()->format('Y-m-d\TH:i:sP'); // Конец события (+1 час)
        $summary = Str::limit(htmlspecialchars(strip_tags($title)), 255);
        $description = Str::limit(htmlspecialchars(strip_tags($comment)), 5000);
        $summary = preg_replace('/[^\P{C}\n]+/u', '', $summary); // Удалить управляющие символы
        $description = preg_replace('/[^\P{C}\n]+/u', '', $description);

        $event = new Calendar\Event([
            'summary' => $summary,
            'description' => $description,
            'start' => [
                'dateTime' => $startDateTime,
                'timeZone' => 'Europe/Moscow',
            ],
            'end' => [
                'dateTime' => $endDateTime,
                'timeZone' => 'Europe/Moscow',
            ],
        ]);

        //dd($redirect_url);

        try {
            $calendarId = 'primary';
            $calendarId = '5jo5qqs0vh83d9adcdl07ji1h8@group.calendar.google.com';

            // Отправляем событие на добавление в Google-календарь в ассинхронном (defer()) режиме
            defer(function() use ($service, $calendarId, $event){
                $service->events->insert($calendarId, $event);
            });

            Log::info('Добавлено событие: ' . $startDateTime . ' ' .$title );
            Log::info($comment);

            return redirect($redirect_url)->with('success', 'Событие добавлено в Google-календарь на ' . $eventDateTime);
        } catch (\Exception $e) {
            //return redirect()->route('login.error')->with('error', $e->getMessage());
            Log::error('Ошибка добавления события в Google календарь: ' . $e->getMessage());
            return redirect($redirect_url)->withErrors(['warn-show' => $e->getMessage()]);
        }
    }
    // Добавление события из планов в календарь
    public function addEventPlan(Plan $plan)   //(Request $request)
    {

        $title = $plan->comment;
        if (isset($plan->doctor) && isset($plan->plantime)){
            $comment = 'Записан на ' . date('d.m.Y', strtotime($plan->plandate)) . ' ' .
                 date('H:i', strtotime($plan->plantime)) . ' в ' .
                 $plan->planClinic->name;

            if (isset($plan->doctor)){
                $comment = $comment . ' к ' . $plan->PlanDoctor->fio;
            }
            if (isset($plan->room)){
                $comment = $comment . ' в ' . $plan->room . ' кабинет.';
            }
            $plandate = $plan->plandate . ' ' . $plan->plantime;
        } else {
            $person = Auth::user()->UserPerson;
            $comment = 'Предварительно нужно записаться';
            if (!empty($person)){
                if (isset($person->clinic)){

                    $comment = $comment . '\n по ссылке: ' . $person->persclinic->link;
                }
            }
            $plandate = $plan->plandate . ' 10:00:00';
        }
        //dd($title . PHP_EOL .$comment . PHP_EOL . $plandate);
        $comment = $comment . " \n Подробнее: https://pride-health.ru/plans/{$plan->id}/edit";

        $result = $this->addEventBase($title, $comment, $plandate);

        return $result;
    }

}
