<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use App\Models\Person;

class Notify extends Model
{
    use HasFactory;

    public $table = 'notifys';

    protected $fillable = ['title', 'message', 'sendtype', 'subscrtype', 'objid', 'address', 'senddate', 'person', 'user'];

    // Имя способа отправки уведомления
    public function getSendTypeNameAttribute(){
        switch ($this->sendtype) {
            case 0: $name = 'не отправлять'; break;
            case 1: $name = 'электронная почта'; break;
            case 2: $name = 'telegram'; break;
            default: $name = 'не определено'; break;
        }

        return $name;
    }

    // Кому: пользователь
    public function getToUserAttribute()
    {
        $user = User::where('id', $this->user)->first();
        return $user;
    }

    // Кому: пациент
     public function getToPersonAttribute()
     {
        $person = null;

        $user = $this->toUser;

        if (!empty($user->person ?? null) ){
            $person = Person::where('id', $user->person)->first();
        }

        return $person;
     }

     // Кому: адрес получателя
    public function getToMailAttribute()
    {
        // Если тип уведомления email и адрес указат - отдаем его
        if ($this->sendtype == 1 && !empty($this->address)){
            $email = $this->address;
        } else {
        $user = $this->toUser;
        $email = $user->email;
        }

        return $email;
    }
    // Кому: Имя получателя
    public function getToNameAttribute()
    {
        $user = $this->toUser;
        if (empty($user)){
            return 'дорогой друг';
        } else {
            return $user->userFirstName;
        }
    }
}
