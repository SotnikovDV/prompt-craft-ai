<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Validation\ValidationException;
use Laravel\Socialite\Facades\Socialite;
use Google\Client;
use Google\Service\Calendar;

use Illuminate\Support\Facades\Log;
/* use SocialiteProviders\Manager\OAuth2\User;
use SocialiteProviders\Manager\Config;
use SocialiteProviders\Manager\SocialiteWasCalled;
 */
use Illuminate\Support\Str;

class LoginController extends Controller
{
    // Переход на страницу аутентификации пользователя
    public function create()
    {
        // сохраним текщее местоположение, что бы вернуться к нему после логина
        redirect()->setIntendedUrl(url()->previous());

        // переходим на страницу регистрации
        return view('auth.login');
    }

    // Аутентификация пользователя
    public function loginAs($credentials, $remember)
    {

        // проверка данных
        /* $credentials = $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string'
        ]); */
        //dd($credentials);

        // аутентифицируем
        if (!Auth::attempt($credentials, $remember)) {
            // если неправильные логин/пароль - возвращаемся обратно
            throw ValidationException::withMessages([
                'email' => trans('auth.failed')  //'Не правильные эл.почта и/или пароль'
            ]);
            /*
            return back()->withInput()->withErrors([
                'email' => 'Не правильные эл.почта и/или пароль'
            ]);
            */
        }

        // обновим cookies в сессии пользователя
        //$request->session()->regenerate();
        //session()->regenerate();

        // если все хорошо - переходим на страницу на которую хотел попасть пользователь
        // return redirect()->intended(route('dashboard'));
        return true;
    }

    // Аутентификация пользователя через страницу входа
    public function store(Request $request)
    {
        // проверка данных
        $credentials = $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string'
        ]);
        $remember = $request->boolean('remember');

        $this->loginAs($credentials, $remember);

        // обновим cookies в сессии пользователя
        $request->session()->regenerate();

        // если все хорошо - переходим на страницу на которую хотел попасть пользователь
        return redirect()->intended(route('dashboard'));
    }

    // Выход
    public function destroy(Request $request){
        //dd($request->all());
        Auth::logout();
        // генерируем новый идентификатор сессии пользователя
        $request->session()->invalidate();
        // обновим токен
        $request->session()->regenerateToken();

        // на стартовую страницу
        return redirect(route('home'));
    }

    /* ------------------------- Авторизация через Yandex ---------------------- */
    // перенаправляем юзера на яндекс Auth
    public function yandex()
    {
        // Сохраним источник вызова авторизации в соцсети (диалог входа, профиль)
        session(['src' => ($_GET['src'] ?? null)]);

        return Socialite::driver('yandex')->redirect();
    }

    // принимаем возвращаемые данные и работаем с ними
    public function yandexRedirect()
    {
        $userYandex = Socialite::driver('yandex')->user();

        // Получаем источник вызова авторизации в соцсети из сессии
        $src = session('src', null);

        if (empty($src)){
            // Авторизация/регистрация через соцсеть для входа на сайт
            // используем firstOrCreate для проверки есть ли такие пользователи в нашей БД
            $user = User::firstOrCreate([
                'email' => $userYandex->email
            ], [
                'name' => $userYandex->user['display_name'],
                'password' => Hash::make(Str::random(24)),
            ]);

            Auth::login($user, true);

            $redirect_url = session('url.intended', route('home'));

        } elseif ($src === 'prf') {
            // Авторизация для связи аккаунта пользователя сайта и соцсети

            $user = Auth::user();

            $redirect_url = route('profile') . '#social';
        } else {
            // прочие причины/источники авторизации ы соцсети
            $redirect_url = route('home');
        }

        if (isset($user)) {
            $user->update([
                'yandex_id' => $userYandex->id,
                'yandex_email' => $userYandex->email,
            ]);
        }
        /* $user->yandex_id = $userYandex->id;
        $user->save(); */

        // если все хорошо - переходим на  страницу, на которую хотел пользователь
        return redirect($redirect_url);

    }
/* ------------------------- Авторизация через Google ---------------------- */
    // перенаправляем юзера на Google Auth
    public function google()
    {
        // Сохраним источник вызова авторизации в соцсети (диалог входа, профиль)
        session(['src' => ($_GET['src'] ?? null)]);

        /* return Socialite::driver('google')
            ->scopes(['https://www.googleapis.com/auth/calendar'])
            ->redirect(); */
        /** @var \Laravel\Socialite\Two\AbstractProvider $socialite */
        $socialite = Socialite::driver('google');
        $socialite->scopes(['https://www.googleapis.com/auth/calendar']);
        return $socialite->redirect();
    }

    // принимаем возвращаемые данные и работаем с ними
    public function googleRedirect()
    {

        //$userGoogle = Socialite::driver('google')->user();

        /** @var \Laravel\Socialite\Two\AbstractProvider $socialite */
        $socialite = Socialite::driver('google');
        $userGoogle = $socialite->stateless()->user();
        session(['google_calendar_token' => $userGoogle->token]);


        // Получаем источник вызова авторизации в соцсети из сессии
        $src = session('src', null);

        if (empty($src)){
            // Авторизация/регистрация через соцсеть для входа на сайт
            // используем firstOrCreate для проверки есть ли такие пользователи в нашей БД
            $user = User::firstOrCreate([
                'email' => $userGoogle->email
            ], [
                'name' => $userGoogle->user['name'],
                'password' => Hash::make(Str::random(24)),
            ]);

            Auth::login($user, true);

            $redirect_url = session('url.intended', route('home'));

        } elseif ($src === 'prf') {
            // Авторизация для связи аккаунта пользователя сайта и соцсети

            $user = Auth::user();

            $redirect_url = route('profile') . '#social';
        } else {
            // прочие причины/источники авторизации ы соцсети
            $redirect_url = route('home');
        }

        if (isset($user)) {
            $user->update([
                'google_id' => $userGoogle->id,
                'google_token' => $userGoogle->token,
                'google_email' => $userGoogle->email,
            ]);
        }

        // если все хорошо - переходим на  страницу, на которую хотел пользователь
        return redirect($redirect_url)->with('success', 'Успешная авторизация через Google');

    }

    public function loginError()
    {
        // сохраним текщее местоположение, что бы вернуться к нему после логина
        redirect()->setIntendedUrl(url()->previous());

        // переходим на страницу регистрации
        return view('errors.login');
    }

}

/*
SocialiteProviders\Manager\OAuth2\User {#547 ▼ // app/Http/Controllers/Auth/LoginController.php:139
  +id: "113554717208532046115"
  +nickname: "Дмитрий Сотников"
  +name: "Дмитрий Сотников"
  +email: "dvst.com@gmail.com"
  +avatar: "https://lh3.googleusercontent.com/a/ACg8ocLCEYoxgcycBQZy-dErh2QbBe1JgHy82MiuBwoseFRf_yASQpiN=s96-c"
  +user: array:7 [▼
    "sub" => "113554717208532046115"
    "name" => "Дмитрий Сотников"
    "given_name" => "Дмитрий"
    "family_name" => "Сотников"
    "picture" => "https://lh3.googleusercontent.com/a/ACg8ocLCEYoxgcycBQZy-dErh2QbBe1JgHy82MiuBwoseFRf_yASQpiN=s96-c"
    "email" => "dvst.com@gmail.com"
    "email_verified" => true
  ]
  +attributes: array:5 [▼
    "id" => "113554717208532046115"
    "nickname" => "Дмитрий Сотников"
    "name" => "Дмитрий Сотников"
    "email" => "dvst.com@gmail.com"
    "avatar" => "https://lh3.googleusercontent.com/a/ACg8ocLCEYoxgcycBQZy-dErh2QbBe1JgHy82MiuBwoseFRf_yASQpiN=s96-c"
  ]
  +token: "
ya29.a0AeDClZBJ5lxKkTgmgR4vX_7MtMzLcpB8wvrPhTIH9Mx0P85X3vhVjlXaPYZlWT3gRa_6YcB599rs19kSTcezNgb_586gCoBGs97NxdvUFoBWbE_tARFwv-m5Si70NBX0RGsWsaNAjPtbqJeDaCvRMeMDq
 ▶
"
  +refreshToken: null
  +expiresIn: 3599
  +approvedScopes: array:3 [▼
    0 => "https://www.googleapis.com/auth/userinfo.profile"
    1 => "https://www.googleapis.com/auth/userinfo.email"
    2 => "openid"
  ]
  +accessTokenResponseBody: array:5 [▼
    "access_token" => "
ya29.a0AeDClZBJ5lxKkTgmgR4vX_7MtMzLcpB8wvrPhTIH9Mx0P85X3vhVjlXaPYZlWT3gRa_6YcB599rs19kSTcezNgb_586gCoBGs97NxdvUFoBWbE_tARFwv-m5Si70NBX0RGsWsaNAjPtbqJeDaCvRMeMDq
 ▶
"
    "expires_in" => 3599
    "scope" => "https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email openid"
    "token_type" => "Bearer"
    "id_token" => "
eyJhbGciOiJSUzI1NiIsImtpZCI6ImU4NjNmZTI5MmZhMmEyOTY3Y2Q3NTUxYzQyYTEyMTFiY2FjNTUwNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiO
 ▶
"
  ]
}
   */
  /*;
  SocialiteProviders\Manager\OAuth2\User {#545 ▼ // app/Http/Controllers/Auth/LoginController.php:108
  +id: "4563008"
  +nickname: "SotnikovDV"
  +name: "Дмитрий Сотников"
  +email: "SotnikovDV@yandex.ru"
  +avatar: "https://avatars.yandex.net/get-yapic/27274/xJMBJxknhEd3zPJtMKLe1ZTALAY-1/islands-200"
  +user: array:15 [▼
    "id" => "4563008"
    "login" => "SotnikovDV"
    "client_id" => "9ed2ba3e66854e46b6c18bc9cab98c54"
    "display_name" => "SotnikovDV"
    "real_name" => "Дмитрий Сотников"
    "first_name" => "Дмитрий"
    "last_name" => "Сотников"
    "sex" => "male"
    "default_email" => "SotnikovDV@yandex.ru"
    "emails" => array:1 [▶]
    "birthday" => "1969-06-04"
    "default_avatar_id" => "27274/xJMBJxknhEd3zPJtMKLe1ZTALAY-1"
    "is_avatar_empty" => false
    "default_phone" => array:2 [▼
      "id" => 270490895
      "number" => "+79031819127"
    ]
    "psuid" => "1.AAyEfA.nJ-rtohR1zkwi6qdeM2J0g.dHAlOGEHGEAWFKroOvwDkw"
  ]
  +attributes: array:5 [▼
    "id" => "4563008"
    "nickname" => "SotnikovDV"
    "name" => "Дмитрий Сотников"
    "email" => "SotnikovDV@yandex.ru"
    "avatar" => "https://avatars.yandex.net/get-yapic/27274/xJMBJxknhEd3zPJtMKLe1ZTALAY-1/islands-200"
  ]
  +token: "y0_AgAAAAAARaBAAAyEfAAAAAESdg6NAADJwHIzfYtP7ZxFuoJLxuDPDNXSLg"
  +refreshToken: "1:rmC3CPpFeritCyhM:lT-6RrpdEPs9zQ1RAL9D90KwzEqe-gpTX_ach6xm6VQlNvUnthU-1BCy9yYxsvI-6rzGG9EZucQ6TDNOCA:oB5lZASS5boW-agUbtwyMg"
  +expiresIn: 28759676
  +approvedScopes: []
  +accessTokenResponseBody: array:4 [▼
    "access_token" => "y0_AgAAAAAARaBAAAyEfAAAAAESdg6NAADJwHIzfYtP7ZxFuoJLxuDPDNXSLg"
    "expires_in" => 28759676
    "refresh_token" => "1:rmC3CPpFeritCyhM:lT-6RrpdEPs9zQ1RAL9D90KwzEqe-gpTX_ach6xm6VQlNvUnthU-1BCy9yYxsvI-6rzGG9EZucQ6TDNOCA:oB5lZASS5boW-agUbtwyMg"
    "token_type" => "bearer"
  ]
}
  */
