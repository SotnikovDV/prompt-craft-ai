<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Models\Notify;

class NotifyController extends Controller
{
    public function index()
    {
        $notifys = Notify::where('user', auth()->user()->id)
            //Notify::where('person', auth()->user()->user_to_person()->id)
            ->where('sendtype', 1)
            ->where('created_at', '>=', now()->subYear())
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        
        return view('notifys.index', compact('notifys'));
    }
}
