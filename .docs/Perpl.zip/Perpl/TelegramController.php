<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Person;
use App\Models\Plan;
use App\Models\Measure;

class TelegramController extends Controller
{
    public $ph_bot_token;

    public function __construct()
    {
        $this->ph_bot_token = config('services.telegram-bot-api.token');
    }

    // Обработка сообщений от бота PrideHealtBot
    public function handle(Request $request)
    {
        // Получаем данные из запроса Telegram
        $data = $request->all();
        $callbackQuery = $request->input('callback_query');

        /* if ($callbackQuery) {
            $telegramUserId = $callbackQuery['from']['id'];
            $telegramUsername = $callbackQuery['from']['username'] ?? null;
            $telegramUserFirstName = $callbackQuery['from']['first_name'] ?? 'друг';
            $telegramChatId = $callbackQuery['message']['chat']['id'];
        }
 */
        if (array_key_exists('message', $data)) {

            //Log::info($data);

            // Получаем ID пользователя Telegram
            $telegramUserId = $data['message']['from']['id'];
            $telegramUsername = $data['message']['from']['username'] ?? null;
            $telegramUserFirstName = $data['message']['from']['first_name'] ?? 'друг';
            $telegramChatId = $data['message']['from']['id'];
            $telegramUserEntitiesType = $data['message']['entities'][0]['type'] ?? 'none';
            $telegramUserText = $data['message']['text'] ?? null;


            // пробуем найти пользователя по TelegramID
            $user = $this->getUserByTelegramID($telegramUserId);
            if (!empty($user)) {
                $userFirstName = $user->userFirstName;
            } else {
                $userFirstName = 'неизвестный друг';
            }

            // Определяем тип сообщения
            // 1. Если просто адрес эл.почты - то это регистрация
            if ($telegramUserEntitiesType == 'email') {

                $user = $this->setUserTelegramID($telegramUserText, $telegramUsername, $telegramUserId, $telegramChatId);

                // Отправляем ответ пользователю
                if (!empty($user)) {
                    $personName = $user->UserPerson->name ?? $user->name;
                    $this->sendTelegramMessage($telegramChatId, 'Привет ' . $personName . '!' . PHP_EOL . 'Ты успешно подключил рассылку уведомлений от сайта pride-health.ru в Telegram!');
                } else {
                    // пользователя не нашли
                    $this->sendTelegramMessage($telegramChatId, 'Привет ' . $telegramUserFirstName . '!' . PHP_EOL . 'К сожалению, пользователя с эл.почтой ' . $telegramUserText . ' не существует на сайте pride-health.ru !');
                }
                // 2. Команда бота
            } elseif ($telegramUserEntitiesType == 'bot_command') {
                Log::info($data);

                // информация о подключении телеграм-аккаугта
                if ($telegramUserText == '/start') {
                    if (!empty($user)) {
                        $message = 'Привет ' . $userFirstName . '!' . PHP_EOL
                            . 'Твой телеграм-аккаунт привязан к пользователю сайта с эл.почтой ' . $user->email;
                    } else {
                        $message = 'Привет ' . $userFirstName . '!' . PHP_EOL
                            . 'Твой телеграм-аккаунт не связан с сайтом pride-health.ru' . PHP_EOL
                            . 'Если ты хочешь привязать свой телеграм-аккаунт, напиши здесь адрес своей электронной почты, с которой ты регистрировался на сайте pride-health.ru и нажми [Enter]';
                    }


                } // справка по командам моей медсестре Полине
                elseif ($telegramUserText == '/help') {
                    $message = '*Команды для медсестры Полины:*' . PHP_EOL . PHP_EOL
                        . 'Полина глуховата ((. Позвать ее можно через Алису.' . PHP_EOL
                        . 'Что бы обратиться к Полине, скажите: `Алиса попроси нашу Полину...`' . PHP_EOL . PHP_EOL
                        . 'Полина может выполнить следующие команды:' . PHP_EOL . PHP_EOL
                        . '1. "`Какие таблетки мне надо принять ... ?`"' . PHP_EOL
                        . ' дополнительно вы можете указать время дня (утро, обед, вечер) и когда по отношению к еде (до, во время, после)' . PHP_EOL . PHP_EOL
                        . '2. "`Отметь прием [лекарство] утром`"' . PHP_EOL . PHP_EOL
                        . '3. "`Запомни мое давление 120 на 80, пульс 60`"' . PHP_EOL . PHP_EOL
                        . '4. "`Создай новую заметку`", дальше диктуйте заметку. Когда закончите, скажите: "`Конец заметки`".' . PHP_EOL . PHP_EOL
                        . '5. "`Какие у меня планы?`"' . PHP_EOL . PHP_EOL
                        . '*Команды для бота Pride-Health:*' . PHP_EOL . PHP_EOL
                        . '1. `/pressure` - получить 10 последних измерений давления' . PHP_EOL
                        . '2. `/plans` - узнать запланированные мероприятия' . PHP_EOL
                        . '3. `/visits` - узнать запланированные визиты к врачу' . PHP_EOL . PHP_EOL
                        . '*💡 Быстрый ввод измерений:*' . PHP_EOL
                        . 'Отправьте три числа через пробел или запятую:' . PHP_EOL
                        . '`120 80 72` или `120, 80, 72`' . PHP_EOL
                        . '(САД ДАД Пульс)';
                }
                // Обработка команды /plans узнать какие планы
                elseif ($telegramUserText == '/plans') {
                    if (!empty($user)) {
                        $message = $this->handlePlanQueryCommand($user);
                    } else {
                        $message = 'Привет ' . $userFirstName . '!' . PHP_EOL
                        . 'Твой телеграм-аккаунт не связан с сайтом pride-health.ru' . PHP_EOL
                        . 'Если ты хочешь привязать свой телеграм-аккаунт, напиши здесь адрес своей электронной почты, с которой ты регистрировался на сайте pride-health.ru и нажми [Enter]';
                    }
                }
                // Обработка команды /visits узнать когда записан к врачу
                elseif ($telegramUserText == '/visits') {
                    if (!empty($user)) {
                        $message = $this->handlePlanVisitCommand($user);
                    } else {
                        $message = 'Привет ' . $userFirstName . '!' . PHP_EOL
                        . 'Твой телеграм-аккаунт не связан с сайтом pride-health.ru' . PHP_EOL
                        . 'Если ты хочешь привязать свой телеграм-аккаунт, напиши здесь адрес своей электронной почты, с которой ты регистрировался на сайте pride-health.ru и нажми [Enter]';
                    }
                }
                // обработка команды /pressure - дневник давления за месяц
                elseif ($telegramUserText == '/pressure') {
                    if (!empty($user)) {
                        $message = $this->handlePressureCommand($user);
                    } else {
                        $message = 'Привет ' . $userFirstName . '!' . PHP_EOL
                        . 'Твой телеграм-аккаунт не связан с сайтом pride-health.ru' . PHP_EOL
                        . 'Если ты хочешь привязать свой телеграм-аккаунт, напиши здесь адрес своей электронной почты, с которой ты регистрировался на сайте pride-health.ru и нажми [Enter]';
                    }
                }
                // отключить оповещения в телеграм
                elseif ($telegramUserText == '/bye' || $telegramUserText == '/goodbye') {
                    if (!empty($user)) {
                        $user->update([
                            'telegram_user_id' => null,
                            'telegram_username' => null,
                            'telegram_chat_id' => null,
                        ]);
                        $message = 'Привет ' . $userFirstName . '!' . PHP_EOL
                            . 'Ты отключил свой телеграм-аккаунт от сайта pride-health.ru .' . PHP_EOL
                            . 'Больше ты не будешь получать здесь уведомления от сайта.' . PHP_EOL
                            . 'Если ты захочешь привязать свой телеграм-аккаунт снова, напиши здесь адрес своей электронной почты, с которой ты регистрировался на сайте pride-health.ru и нажми [Enter]';
                    } else {
                        $message = 'Привет ' . $userFirstName . '!' . PHP_EOL
                            . 'Твой телеграм-аккаунт не связан с сайтом pride-health.ru' . PHP_EOL
                            . 'Если ты хочешь привязать свой телеграм-аккаунт, напиши здесь адрес своей электронной почты, с которой ты регистрировался на сайте pride-health.ru и нажми [Enter]';
                    }
                } else {
                    $message = 'Привет ' . $userFirstName . '!' . PHP_EOL
                        . 'Эту команду я пока не умею выполнять :(';
                }


                // отправим сообщение пользователю
                $this->sendTelegramMessage($telegramChatId, $message);

                        } else {
                // Обычные сообщения (не команды)
                Log::info('Обработка обычного сообщения', [
                    'message' => $telegramUserText,
                    'user_found' => !empty($user),
                    'entities_type' => $telegramUserEntitiesType
                ]);

                if (!empty($user)) {
                    // Проверяем, является ли сообщение измерением давления
                    $pressureData = $this->parsePressureMessage($telegramUserText);
                    if ($pressureData) {
                        $message = $this->savePressureMeasurement($user, $pressureData);
                    } else {
                        $message = 'Привет ' . $userFirstName . '!' . PHP_EOL
                            . 'Эту команду я пока не умею выполнять :(' . PHP_EOL . PHP_EOL
                            . '💡 *Подсказка:* Отправьте измерение давления в формате:' . PHP_EOL
                            . '`120 80 72` или `120, 80, 72` (САД ДАД Пульс)';
                    }
                } else {
                    $message = 'Привет ' . $userFirstName . '!' . PHP_EOL
                        . 'Твой телеграм-аккаунт не связан с сайтом pride-health.ru' . PHP_EOL
                        . 'Если ты хочешь привязать свой телеграм-аккаунт, напиши здесь адрес своей электронной почты, с которой ты регистрировался на сайте pride-health.ru и нажми [Enter]';
                }

                // отправим сообщение пользователю
                $this->sendTelegramMessage($telegramChatId, $message);
            }

            // Отправляем ответ пользователю (опционально)
            //return response()->json(['status' => 'success']);
            // $this->sendTelegramMessage($telegramUserId, 'Привет ' . $personName . '!' . PHP_EOL .'Ты успешно подключил рассылку уведомлений от сайта pride-health.ru в Telegram!');
        } else {
            Log::info('Запрос бота Telegram: неверный формат данных');
            return response()->json(['status' => 'fail']);
        }
    }
    // поиск пользователя по TelegramID
    public function getUserByTelegramID($telegramUserId)
    {

        // Найдем пользователя по его идентификатору в системе или по username
        $user = User::where('telegram_user_id', $telegramUserId)->first();

        return $user;

    }
    // регистрация телеграм-аккаунта пользователя
    public function setUserTelegramID($email, $userName, $userId, $chatId)
    {

        $emailLow = mb_strtolower($email);
        // Найдем пользователя по его идентификатору в системе или по username
        $user = User::where('email', $emailLow)->first();

        if ($user) {
            // Сохраняем Telegram ID пользователя в базе данных
            $user->telegram_username = $userName;
            $user->telegram_user_id = $userId;
            $user->telegram_chat_id = $chatId;
            $user->save();
            return $user;
        } else {
            return null;
        }
    }
    /*
    Обработка команды узнать какие планы
    */
   private function handlePlanQueryCommand($user = null)
   {
        $person = Person::where('id', $user->person)->first();
        $personName = $person->name;

       // Получаем список плановых мероприятий на ближайший год
       $plans = Plan::where('person', $user->person)
           ->whereRaw('(plandate >= ? and plandate < ?)', [now()->format('Y-m-d'), now()->addYear()->format('Y-m-d')])
           ->orderBy('plandate')
           ->orderBy('plantime')
           ->get();


       if ($plans->isEmpty()) {
           return 'У Вас нет запланированных мероприятий';
       }

       $planlist = '';
       // Формируем список планов
       foreach ($plans as $plan) {
           $planlist .= $planlist ? ', ' . PHP_EOL . PHP_EOL : '';
           $planlist .= '⏰ *' . date('d.m.Y', strtotime($plan->plandate))
           . (isset($plan->plantime) ? ' в ' . date('H:i', strtotime($plan->plantime)): '')
           . (isset($plan->clinic) ? ' в ' . $plan->planClinic->name: '')
           . '* [' . $plan->comment . '](' . route('plans.edit', $plan->id) . ')';
       }
       return '📅 *'.$personName . ', Вы запланировали следующие мероприятия:*' . PHP_EOL . PHP_EOL . $planlist . PHP_EOL . PHP_EOL
             . '🌐 [Открыть планы на сайте Pride-Health](' . route('plans.index') . ')';
   }
    /*
    Обработка команды узнать когда записан к врачу
    */
    private function handlePlanVisitCommand($user = null)
    {
        $person = Person::where('id', $user->person)->first();
        $personName = $person->name;

        // Получаем список плановых мероприятий на ближайший год, связанных с врачами
        $plans = Plan::where('person', $user->person)
            ->whereRaw('(plandate >= ? and plandate < ?)', [now()->format('Y-m-d'), now()->addYear()->format('Y-m-d')])
            ->whereIn('plantype', [1,2,3])
            ->orderBy('plandate')->get();

        if ($plans->isEmpty()) {
            return $personName . ', у Вас нет запланированных визитов к врачу';
        }

        $planlist = '';
        foreach ($plans as $plan) {
            $planlist .= $planlist ? ', ' . PHP_EOL . PHP_EOL : '';
            $planlist .= '⏰ *' . date('d.m.Y', strtotime($plan->plandate)) . ' в ' . date('H:i', strtotime($plan->plantime))
                      . '* [' . $plan->comment . '](' . route('plans.edit', $plan->id) . ')';
        }
        return '📅 *'.$personName . ', Вы запланировали следующие визиты к врачу:*' . PHP_EOL . PHP_EOL . $planlist . PHP_EOL . PHP_EOL
             . '🌐 [Открыть планы на сайте Pride-Health](' . route('plans.index') . ')';
    }
    protected function sendTelegramMessage($chatId, $message)
    {
        $token = $this->ph_bot_token;
        $url = "https://api.telegram.org/bot{$token}/sendMessage";

        $client = new \GuzzleHttp\Client();
        $client->post($url, [
            'form_params' => [
                'chat_id' => $chatId,
                'text' => $message,
                'parse_mode' => 'Markdown'
            ],
        ]);
    }

    /*
    Обработка команды /pressure - дневник давления за месяц
    */
    private function handlePressureCommand($user = null)
    {
        $person = Person::where('id', $user->person)->first();
        $personName = $person->name;

        $dte = now()->format('Y-m-d');
        $dte2 = Carbon::parse($dte)->addDays(1)->format('Y-m-d');
        $dtbm = now()->subMonth()->format('Y-m-d');

        // 10 последних измерений (утро/вечер)
        $sql = 'SELECT DATE(meas_date) AS "date",
                       CASE WHEN HOUR(meas_date) BETWEEN 5 AND 13 THEN "Утро" ELSE "Вечер" END AS "time_of_day",
                       MAX(CASE WHEN meastype = 1 THEN CAST(FLOOR(mvalue) AS CHAR) END) AS "SP",
                       MAX(CASE WHEN meastype = 2 THEN CAST(FLOOR(mvalue) AS CHAR) END) AS "DP",
                       MAX(CASE WHEN meastype = 3 THEN CAST(FLOOR(mvalue) AS CHAR) END) AS "HR",
                       "" AS "note"
                FROM measures
                WHERE person = ' . $user->person . '
                GROUP BY DATE(meas_date), CASE WHEN HOUR(meas_date) BETWEEN 5 AND 13 THEN "Утро" ELSE "Вечер" END
                ORDER BY DATE(meas_date) DESC, FIELD(CASE WHEN HOUR(meas_date) BETWEEN 5 AND 13 THEN "Утро" ELSE "Вечер" END, "Утро", "Вечер") DESC
                LIMIT 10';

        $measures = DB::select($sql);

        if (empty($measures)) {
            return $personName . ', у Вас нет последних записей измерений давления.';
        }

        // Формируем краткий отчет
        $report = '📊 *'.$personName . ', вот Ваши последние измерения давления:*' . PHP_EOL . PHP_EOL;

        $current_date = null;
        foreach ($measures as $measure) {
            if ($measure->time_of_day == 'Утро' || $current_date != $measure->date) {
                $report .= '*'.date('d.m.Y', strtotime($measure->date)) . '* ' . PHP_EOL;
                $current_date = $measure->date;
            }

            $report .= '  ' . $measure->time_of_day . ': ';
            $report .= ($measure->SP ?: '-') . '/' . ($measure->DP ?: '-') . ' мм рт.ст.';
            if ($measure->HR) {
                $report .= ', пульс ' . $measure->HR . ' уд/мин';
            }
            $report .= PHP_EOL;
        }

        $report .= PHP_EOL . '📋 [Скачать отчет о давлении за месяц в PDF формате](' . route('measures.export-pdf', ['dtb' => $dtbm, 'dte' => $dte2]) . ')'
                . PHP_EOL . PHP_EOL . '🌐 [Открыть дневник давления на сайте Pride-Health](' . route('measures.report') . ')';

        return $report;
    }

        /*
    Парсинг сообщения с измерением давления
    */
    private function parsePressureMessage($message)
    {
        // Добавляем отладочную информацию
        Log::info('Парсинг сообщения давления', [
            'original_message' => $message,
            'message_length' => strlen($message)
        ]);

        // Очищаем сообщение от лишних символов
        $cleanMessage = preg_replace('/[^\d\s,]/', '', $message);

        // Разбиваем на числа по пробелам и запятым
        $numbers = preg_split('/[\s,]+/', trim($cleanMessage));

        // Фильтруем только числа
        $numbers = array_filter($numbers, function($num) {
            return is_numeric($num) && $num > 0;
        });

        Log::info('Результат парсинга', [
            'clean_message' => $cleanMessage,
            'numbers_count' => count($numbers),
            'numbers' => $numbers
        ]);

        // Проверяем, что у нас ровно 3 числа
        if (count($numbers) === 3) {
            $numbers = array_values($numbers); // Переиндексируем массив

            // Проверяем разумные диапазоны значений
            $systolic = (int)$numbers[0];   // САД (систолическое)
            $diastolic = (int)$numbers[1];  // ДАД (диастолическое)
            $pulse = (int)$numbers[2];      // Пульс

            Log::info('Проверка диапазонов', [
                'systolic' => $systolic,
                'diastolic' => $diastolic,
                'pulse' => $pulse,
                'systolic_valid' => ($systolic >= 80 && $systolic <= 250),
                'diastolic_valid' => ($diastolic >= 40 && $diastolic <= 150),
                'pulse_valid' => ($pulse >= 40 && $pulse <= 200)
            ]);

            // Проверяем разумные диапазоны
            if ($systolic >= 80 && $systolic <= 250 &&
                $diastolic >= 40 && $diastolic <= 150 &&
                $pulse >= 40 && $pulse <= 200) {

                return [
                    'systolic' => $systolic,
                    'diastolic' => $diastolic,
                    'pulse' => $pulse
                ];
            }
        }

        return null;
    }

    /*
    Сохранение измерения давления
    */
    private function savePressureMeasurement($user, $pressureData)
    {
        $person = Person::where('id', $user->person)->first();
        $personName = $person->name;

        $datetime = now();

        // Получаем ID показателей из конфигурации
        $sad_id = dh_config('mst_sad_id'); // Систолическое давление
        $dad_id = dh_config('mst_dad_id'); // Диастолическое давление
        $hr_id = dh_config('mst_hr_id');   // Пульс

        try {
            // Сохраняем систолическое давление
            Measure::create([
                'meastype' => $sad_id,
                'meas_date' => $datetime,
                'mvalue' => $pressureData['systolic'],
                'person' => $user->person,
            ]);

            // Сохраняем диастолическое давление
            Measure::create([
                'meastype' => $dad_id,
                'meas_date' => $datetime,
                'mvalue' => $pressureData['diastolic'],
                'person' => $user->person,
            ]);

            // Сохраняем пульс
            Measure::create([
                'meastype' => $hr_id,
                'meas_date' => $datetime,
                'mvalue' => $pressureData['pulse'],
                'person' => $user->person,
            ]);

            // Формируем ответ
            $response = '✅ *Измерение сохранено!*' . PHP_EOL . PHP_EOL;
            $response .= '📊 *' . $personName . ', Ваши показатели:*' . PHP_EOL;
            $response .= '• Систолическое АД: *' . $pressureData['systolic'] . ' мм рт.ст.*' . PHP_EOL;
            $response .= '• Диастолическое АД: *' . $pressureData['diastolic'] . ' мм рт.ст.*' . PHP_EOL;
            $response .= '• Пульс: *' . $pressureData['pulse'] . ' уд/мин*' . PHP_EOL;
            $response .= '• Время: *' . $datetime->format('d.m.Y H:i') . '*' . PHP_EOL . PHP_EOL;

            // Добавляем оценку давления
            $pressureStatus = $this->evaluatePressure($pressureData['systolic'], $pressureData['diastolic']);
            $response .= '💡 *Оценка:* ' . $pressureStatus . PHP_EOL . PHP_EOL;

            $response .= '🌐 [Посмотреть все измерения на сайте](' . route('measures.index') . ')';

            return $response;

        } catch (\Exception $e) {
            Log::error('Ошибка сохранения измерения давления из Telegram', [
                'user_id' => $user->id,
                'pressure_data' => $pressureData,
                'error' => $e->getMessage()
            ]);

            return '❌ *Ошибка сохранения измерения.*' . PHP_EOL . 'Попробуйте еще раз или обратитесь к администратору.';
        }
    }

    /*
    Оценка показателей давления
    */
    private function evaluatePressure($systolic, $diastolic)
    {
        if ($systolic < 90 && $diastolic < 60) {
            return 'Гипотония (пониженное давление)';
        } elseif ($systolic < 120 && $diastolic < 80) {
            return 'Нормальное давление';
        } elseif ($systolic < 130 && $diastolic < 85) {
            return 'Нормальное давление (малость высоковато)';
        } elseif ($systolic < 140 && $diastolic < 90) {
            return 'Предгипертония';
        } elseif ($systolic < 160 && $diastolic < 100) {
            return 'Гипертония 1 степени';
        } elseif ($systolic < 180 && $diastolic < 110) {
            return 'Гипертония 2 степени';
        } else {
            return 'Гипертония 3 степени (требует внимания!)';
        }
    }
}

/* Запрос от Телеграм-бота:
array (
  'update_id' => 53828585,
  'message' =>
  array (
    'message_id' => 25,
    'from' =>
    array (
      'id' => 320254532,
      'is_bot' => false,
      'first_name' => 'Dmitry',
      'last_name' => 'S',
      'username' => 'DVSot',
      'language_code' => 'ru',
      'is_premium' => true,
    ),
    'chat' =>
    array (
      'id' => 320254532,
      'first_name' => 'Dmitry',
      'last_name' => 'S',
      'username' => 'DVSot',
      'type' => 'private',
    ),
    'date' => 1729837753,
    'text' => '/start',
    'entities' =>
    array (
      0 =>
      array (
        'offset' => 0,
        'length' => 6,
        'type' => 'bot_command',
      ),
    ),
  ),
)
*/
