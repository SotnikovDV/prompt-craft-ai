<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\BatchTaskController;
use App\Http\Controllers\LlmProviderController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Chat routes
    Route::get('/chat', [ChatController::class, 'index'])->name('chat.index');
    Route::get('/chat/{session}', [ChatController::class, 'show'])->name('chat.show');
    Route::post('/chat/sessions', [ChatController::class, 'createSession'])->name('chat.create-session');
    Route::post('/chat/{session}/messages', [ChatController::class, 'sendMessage'])->name('chat.send-message');
    Route::delete('/chat/sessions/{session}', [ChatController::class, 'deleteSession'])->name('chat.delete-session');
    Route::post('/chat/{session}/clear', [ChatController::class, 'clearChat'])->name('chat.clear');

    // Batch tasks routes
    Route::get('/batch-tasks', [BatchTaskController::class, 'index'])->name('batch-tasks.index');
    Route::get('/batch-tasks/create', [BatchTaskController::class, 'create'])->name('batch-tasks.create');
    Route::post('/batch-tasks', [BatchTaskController::class, 'store'])->name('batch-tasks.store');
    Route::get('/batch-tasks/{task}', [BatchTaskController::class, 'show'])->name('batch-tasks.show');
    Route::delete('/batch-tasks/{task}', [BatchTaskController::class, 'destroy'])->name('batch-tasks.destroy');

    // LLM Providers routes
    Route::get('/providers', [LlmProviderController::class, 'index'])->name('providers.index');
    Route::get('/providers/create', [LlmProviderController::class, 'create'])->name('providers.create');
    Route::post('/providers', [LlmProviderController::class, 'store'])->name('providers.store');
    Route::get('/providers/{provider}/edit', [LlmProviderController::class, 'edit'])->name('providers.edit');
    Route::put('/providers/{provider}', [LlmProviderController::class, 'update'])->name('providers.update');
    Route::delete('/providers/{provider}', [LlmProviderController::class, 'destroy'])->name('providers.destroy');

    // AI Chat через OpenRouter
    Route::get('openroute/chat', function () {
        return view('openroute.chat');
    })->name('openroute.chat');

    // Test route for LLM service
    Route::get('/test-llm', function () {
        try {
            $provider = \App\Models\LlmProvider::active()->first();
            if (!$provider) {
                return response()->json(['error' => 'No active providers found'], 404);
            }

            $llmService = app(\App\Services\LlmService::class);
            $response = $llmService->sendMessage($provider, [
                ['role' => 'user', 'content' => 'Hello, how are you?']
            ]);

            return response()->json(['success' => true, 'response' => $response]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    })->name('test.llm');

    // Test route for Local LLM connection
    Route::get('/test-local-llm', function () {
        try {
            $endpoint = 'http://10.11.30.80:1234/v1/chat/completions';

            // Проверяем доступность локальной модели
            $response = \Illuminate\Support\Facades\Http::timeout(30)
                ->withHeaders([
                    'Content-Type' => 'application/json',
                ])
                ->post($endpoint, [
                    'model' => 'gemma3n-e4b-it-scout',
                    'messages' => [
                        ['role' => 'user', 'content' => 'Привет! Как дела?']
                    ],
                    'temperature' => 0.7,
                    'max_tokens' => 100,
                    'stream' => false,
                ]);

            if (!$response->successful()) {
                return response()->json([
                    'error' => 'Local LLM connection failed',
                    'status' => $response->status(),
                    'body' => $response->body()
                ], 500);
            }

            $data = $response->json();

            return response()->json([
                'success' => true,
                'local_llm_response' => $data,
                'response_structure' => [
                    'keys' => array_keys($data),
                    'has_choices' => isset($data['choices']),
                    'choices_count' => isset($data['choices']) ? count($data['choices']) : 0,
                    'content' => $data['choices'][0]['message']['content'] ?? 'No content',
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Local LLM test failed: ' . $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ], 500);
        }
    })->name('test.local-llm');
});

require __DIR__ . '/auth.php';
