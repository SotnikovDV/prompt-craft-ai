<?php

namespace App\Http\Controllers;

use App\Models\ChatSession;
use App\Models\ChatMessage;
use App\Models\LlmProvider;
use App\Services\LlmService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class ChatController extends Controller
{
    protected $llmService;

    public function __construct(LlmService $llmService)
    {
        $this->llmService = $llmService;
    }

    public function index()
    {
        $sessions = \App\Models\User::find(Auth::id())->chatSessions()->with('llmProvider')->latest()->get();
        $providers = LlmProvider::active()->get();

        return view('chat.index', compact('sessions', 'providers'));
    }

    public function show(ChatSession $session)
    {
        $messages = $session->messages()->where('is_hidden', false)->orderBy('created_at')->get();
        $providers = LlmProvider::active()->get();

        return view('chat.show', compact('session', 'messages', 'providers'));
    }

    public function clearChat(ChatSession $session)
    {
        // Проверяем, что пользователь владеет этой сессией
        if ($session->user_id !== Auth::id()) {
            return response()->json([
                'success' => false,
                'error' => 'Unauthorized'
            ], 403);
        }

        // Скрываем все сообщения в этой сессии
        $session->messages()->update(['is_hidden' => true]);

        return response()->json([
            'success' => true,
            'message' => 'Chat cleared successfully'
        ]);
    }

    public function createSession(Request $request)
    {
        $request->validate([
            'title' => 'nullable|string|max:255',
            'llm_provider_id' => 'required|exists:llm_providers,id',
            'model' => 'nullable|string',
            'parameters' => 'nullable|array',
        ]);

        $session = ChatSession::create([
            'user_id' => Auth::id(),
            'title' => $request->title ?? 'New Chat',
            'llm_provider_id' => $request->llm_provider_id,
            'model' => $request->get('model'), // Сохраняем null если модель не указана
            'parameters' => $request->parameters ?? [],
        ]);

        return redirect()->route('chat.show', $session);
    }

    public function sendMessage(Request $request, ChatSession $session)
    {
        $request->validate([
            'content' => 'required|string',
        ]);

        // Save user message
        $userMessage = ChatMessage::create([
            'chat_session_id' => $session->id,
            'role' => 'user',
            'content' => $request->content,
        ]);

        // Get conversation history
        $messages = $session->messages()->orderBy('created_at')->get();
        $conversation = $messages->map(function ($message) {
            return [
                'role' => $message->role,
                'content' => $message->content,
            ];
        })->toArray();

        try {
            // Send to LLM
            $provider = $session->llmProvider;
            
            // Подготавливаем параметры, включая модель из сессии
            $parameters = $session->parameters ?? [];
            if ($session->model) {
                $parameters['model'] = $session->model;
            }
            
            // Логируем параметры для отладки
            Log::info("Chat session parameters", [
                'session_id' => $session->id,
                'session_model' => $session->model,
                'parameters' => $parameters,
            ]);
            
            $response = $this->llmService->sendMessage($provider, $conversation, $parameters);

            // Save assistant response
            $assistantMessage = ChatMessage::create([
                'chat_session_id' => $session->id,
                'role' => 'assistant',
                'content' => $response['content'],
                'model_used' => $response['model_used'],
                'tokens_used' => $response['tokens_used'],
                'cost' => $response['cost'],
                'response_time_ms' => $response['response_time_ms'],
                'metadata' => $response['metadata'],
            ]);

            // Update session last activity
            $session->update(['last_activity' => now()]);

            return response()->json([
                'success' => true,
                'message' => $assistantMessage,
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function deleteSession(ChatSession $session)
    {
        if ($session->user_id !== Auth::id()) {
            abort(403);
        }

        $session->delete();

        return redirect()->route('chat.index')->with('success', 'Chat session deleted successfully.');
    }
}
