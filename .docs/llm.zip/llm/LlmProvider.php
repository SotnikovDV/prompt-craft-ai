<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LlmProvider extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'type',
        'api_endpoint',
        'api_key',
        'models',
        'config',
        'is_active',
        'rate_limit',
        'timeout',
    ];

    protected $casts = [
        'models' => 'array',
        'config' => 'array',
        'is_active' => 'boolean',
    ];

    public function chatSessions()
    {
        return $this->hasMany(ChatSession::class);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
