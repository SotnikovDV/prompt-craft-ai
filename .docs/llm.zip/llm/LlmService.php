<?php

namespace App\Services;

use App\Models\LlmProvider;
use OpenAI\Laravel\Facades\OpenAI;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class LlmService
{
    public function sendMessage(LlmProvider $provider, array $messages, array $parameters = [])
    {
        $startTime = microtime(true);

        // Validate provider
        if (!$provider) {
            throw new \Exception("LLM Provider not found");
        }

        if (!$provider->is_active) {
            throw new \Exception("LLM Provider is not active: {$provider->name}");
        }

        Log::info("Sending message to provider: {$provider->name}", [
            'provider_id' => $provider->id,
            'provider_type' => $provider->type,
            'messages_count' => count($messages),
            'parameters' => $parameters
        ]);

        try {
            if ($provider->type == 'local') {
                return $this->sendToLocal($provider, $messages, $parameters, $startTime);
            } else {
                switch ($provider->name) {
                    case 'OpenAI':
                        return $this->sendToOpenAI($provider, $messages, $parameters, $startTime);
                    case 'OpenRouter':
                        return $this->sendToOpenRouter($provider, $messages, $parameters, $startTime);
                    case 'Anthropic':
                        return $this->sendToAnthropic($provider, $messages, $parameters, $startTime);
                    default:
                        throw new \Exception("Unsupported provider: {$provider->name}");
                }
            }
        } catch (\Exception $e) {
            Log::error("LLM API Error: " . $e->getMessage(), [
                'provider' => $provider->name,
                'provider_id' => $provider->id,
                'messages' => $messages,
                'parameters' => $parameters,
                'trace' => $e->getTraceAsString()
            ]);
            throw $e;
        }
    }

    private function sendToOpenAI(LlmProvider $provider, array $messages, array $parameters, $startTime)
    {
        $config = $provider->config ?? [];
        $model = $parameters['model'] ?? $config['model'] ?? 'gpt-3.5-turbo';

        $response = OpenAI::chat()->create([
            'model' => $model,
            'messages' => $messages,
            'temperature' => $parameters['temperature'] ?? $config['temperature'] ?? 0.7,
            'max_tokens' => $parameters['max_tokens'] ?? $config['max_tokens'] ?? 1000,
        ]);

        $endTime = microtime(true);
        $responseTime = round(($endTime - $startTime) * 1000);

        return [
            'content' => $response->choices[0]->message->content,
            'model_used' => $model,
            'tokens_used' => $response->usage->totalTokens,
            'cost' => $this->calculateOpenAICost($model, $response->usage->totalTokens),
            'response_time_ms' => $responseTime,
            'metadata' => [
                'prompt_tokens' => $response->usage->promptTokens,
                'completion_tokens' => $response->usage->completionTokens,
                'total_tokens' => $response->usage->totalTokens,
            ]
        ];
    }

    private function sendToAnthropic(LlmProvider $provider, array $messages, array $parameters, $startTime)
    {
        $config = $provider->config ?? [];
        $model = $parameters['model'] ?? $config['model'] ?? 'claude-3-sonnet-20240229';

        // Use provider-specific timeout or fallback to config
        $timeout = $provider->timeout ?? config('services.llm.timeouts.anthropic', 120);

        $response = Http::timeout($timeout)
            ->withHeaders([
                'x-api-key' => $provider->api_key,
                'anthropic-version' => '2023-06-01',
                'content-type' => 'application/json',
            ])->post('https://api.anthropic.com/v1/messages', [
                'model' => $model,
                'max_tokens' => $parameters['max_tokens'] ?? $config['max_tokens'] ?? 1000,
                'messages' => $messages,
            ]);

        if (!$response->successful()) {
            throw new \Exception("Anthropic API Error: " . $response->body());
        }

        $data = $response->json();
        $endTime = microtime(true);
        $responseTime = round(($endTime - $startTime) * 1000);

        return [
            'content' => $data['content'][0]['text'],
            'model_used' => $model,
            'tokens_used' => $data['usage']['input_tokens'] + $data['usage']['output_tokens'],
            'cost' => $this->calculateAnthropicCost($model, $data['usage']['input_tokens'], $data['usage']['output_tokens']),
            'response_time_ms' => $responseTime,
            'metadata' => [
                'input_tokens' => $data['usage']['input_tokens'],
                'output_tokens' => $data['usage']['output_tokens'],
            ]
        ];
    }

    private function sendToOpenRouter(LlmProvider $provider, array $messages, array $parameters, $startTime)
    {
        $config = $provider->config ?? [];
        $model = $parameters['model'] ?? $config['model'] ?? 'openai/gpt-oss-20b:free';
        $apiKey = $provider->api_key;

        if (!$apiKey) {
            throw new \Exception("OpenRouter API key is required");
        }

        // Use provider-specific timeout or fallback to config
        $timeout = $provider->timeout ?? config('services.llm.timeouts.openrouter', 120);

        $requestData = [
            'model' => $model,
            'messages' => $messages,
            'max_tokens' => $parameters['max_tokens'] ?? $config['max_tokens'] ?? 1000,
            'temperature' => $parameters['temperature'] ?? $config['temperature'] ?? 0.7,
        ];

        Log::info("Sending request to OpenRouter", [
            'model' => $model,
            'messages_count' => count($messages),
            'request_data' => $requestData,
        ]);

        $response = Http::timeout($timeout)
            ->withHeaders([
                'Content-Type' => 'application/json',
                'Authorization' => "Bearer {$apiKey}",
                'HTTP-Referer' => config('app.url'),
                'X-Title' => 'AI Chat via OpenRouter'
            ])
            ->post('https://openrouter.ai/api/v1/chat/completions', $requestData);

        if (!$response->successful()) {
            $errorData = $response->json();
            $errorMessage = $errorData['error']['message'] ?? 'Unknown error';
            throw new \Exception("OpenRouter API Error: {$response->status()} - {$errorMessage}");
        }

        $data = $response->json();

        $endTime = microtime(true);
        $responseTime = round(($endTime - $startTime) * 1000);

        return [
            'content' => $data['choices'][0]['message']['content'] ?? 'No response content',
            'model_used' => $model,
            'tokens_used' => $data['usage']['total_tokens'] ?? 0,
            'cost' => $this->calculateOpenRouterCost($model, $data['usage']['total_tokens'] ?? 0),
            'response_time_ms' => $responseTime,
            'metadata' => [
                'prompt_tokens' => $data['usage']['prompt_tokens'] ?? 0,
                'completion_tokens' => $data['usage']['completion_tokens'] ?? 0,
                'total_tokens' => $data['usage']['total_tokens'] ?? 0,
                'raw_response' => $data,
            ]
        ];
    }

    private function sendToLocal(LlmProvider $provider, array $messages, array $parameters, $startTime)
    {
        $config = $provider->config ?? [];
        $endpoint = $provider->api_endpoint ?? $config['endpoint'] ?? 'http://10.11.30.80:1234/v1/chat/completions';

        // Use provider-specific timeout or fallback to config
        $timeout = $provider->timeout ?? config('services.llm.timeouts.local', 180);

        $requestData = [
            'model' => $parameters['model'] ?? $config['model'] ?? 'gemma3n-e4b-it-scout',
            'messages' => $messages,
            'temperature' => $parameters['temperature'] ?? $config['temperature'] ?? 0.7,
            'max_tokens' => $parameters['max_tokens'] ?? $config['max_tokens'] ?? 1000,
            'stream' => false,
        ];

        Log::info("Sending request to local LLM", [
            'endpoint' => $endpoint,
            'request_data' => $requestData,
        ]);

        $response = Http::timeout($timeout)
            ->withHeaders([
                'Content-Type' => 'application/json',
            ])
            ->post($endpoint, $requestData);

        if (!$response->successful()) {
            throw new \Exception("Local LLM API Error: " . $response->body());
        }

        $data = $response->json();

        // Логируем структуру ответа для отладки
        Log::info("Local LLM response structure", [
            'response_keys' => array_keys($data),
            'has_choices' => isset($data['choices']),
            'choices_count' => isset($data['choices']) ? count($data['choices']) : 0,
        ]);

        $endTime = microtime(true);
        $responseTime = round(($endTime - $startTime) * 1000);

        // OpenAI-compatible response format
        return [
            'content' => $data['choices'][0]['message']['content'] ?? 'No response content',
            'model_used' => $parameters['model'] ?? $config['model'] ?? 'gemma3n-e4b-it-scout',
            'tokens_used' => $data['usage']['total_tokens'] ?? 0,
            'cost' => 0, // Local models are free
            'response_time_ms' => $responseTime,
            'metadata' => [
                'prompt_tokens' => $data['usage']['prompt_tokens'] ?? 0,
                'completion_tokens' => $data['usage']['completion_tokens'] ?? 0,
                'total_tokens' => $data['usage']['total_tokens'] ?? 0,
                'raw_response' => $data, // Добавляем сырой ответ для отладки
            ]
        ];
    }

    private function calculateOpenAICost($model, $tokens)
    {
        $rates = [
            'gpt-4' => ['input' => 0.03, 'output' => 0.06],
            'gpt-4-turbo' => ['input' => 0.01, 'output' => 0.03],
            'gpt-3.5-turbo' => ['input' => 0.0015, 'output' => 0.002],
        ];

        $rate = $rates[$model] ?? $rates['gpt-3.5-turbo'];
        return ($tokens / 1000) * $rate['input']; // Simplified calculation
    }

    private function calculateAnthropicCost($model, $inputTokens, $outputTokens)
    {
        $rates = [
            'claude-3-opus-20240229' => ['input' => 0.015, 'output' => 0.075],
            'claude-3-sonnet-20240229' => ['input' => 0.003, 'output' => 0.015],
            'claude-3-haiku-20240307' => ['input' => 0.00025, 'output' => 0.00125],
        ];

        $rate = $rates[$model] ?? $rates['claude-3-sonnet-20240229'];
        return (($inputTokens / 1000) * $rate['input']) + (($outputTokens / 1000) * $rate['output']);
    }

    private function calculateOpenRouterCost($model, $totalTokens)
    {
        // OpenRouter использует различные модели с разными тарифами
        // Для бесплатных моделей стоимость = 0
        if (str_contains($model, ':free')) {
            return 0;
        }

        // Примерные тарифы для популярных моделей (в долларах за 1K токенов)
        $rates = [
            'openai/gpt-4o' => 0.005,
            'openai/gpt-4o-mini' => 0.00015,
            'openai/gpt-3.5-turbo' => 0.0005,
            'anthropic/claude-3.5-sonnet' => 0.003,
            'anthropic/claude-3-haiku' => 0.00025,
            'google/gemini-2.0-flash-exp' => 0.0001,
            'meta-llama/llama-3.3-70b-instruct' => 0.0002,
            'mistralai/mistral-7b-instruct' => 0.0001,
        ];

        // Ищем точное совпадение или используем базовую модель
        $rate = $rates[$model] ?? 0.001; // По умолчанию $0.001 за 1K токенов

        return ($totalTokens / 1000) * $rate;
    }
}
