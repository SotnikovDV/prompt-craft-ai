<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChatSession extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'title',
        'llm_provider_id',
        'model',
        'parameters',
        'is_active',
        'last_activity',
    ];

    protected $casts = [
        'parameters' => 'array',
        'is_active' => 'boolean',
        'last_activity' => 'datetime',
    ];

    protected $appends = [
        'model',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function llmProvider()
    {
        return $this->belongsTo(LlmProvider::class);
    }

    public function messages()
    {
        return $this->hasMany(ChatMessage::class);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
