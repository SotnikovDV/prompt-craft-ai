<x-app-layout>
    <x-slot name="header">
    <div class="flex justify-between items-center">
        <div class="flex justify-start items-center">
            <a href="{{ route('chat.index') }}"
                    class="bg-gray-500 hover:bg-gray-700 text-white font-bold  py-2 px-4 rounded flex items-center space-x-2 mr-4">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                    </svg>
                    {{-- <span>Back to Sessions</span> --}}
                </a>
            <div>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    {{ $session->title }}
                </h2>
                @if ($session->model)
                    <p class="text-sm text-gray-600 mt-1">
                        @if ($session->llmProvider)
                            Provider: <span class="font-medium text-green-600">{{ $session->llmProvider->name }} | </span>
                        @endif
                        Model: <span class="font-medium text-blue-600">{{ $session->model }}</span>
                        
                    </p>
                @else
                    <p class="text-sm text-gray-600 mt-1">
                        Provider: <span
                            class="font-medium text-green-600">{{ $session->llmProvider->name ?? 'Unknown' }}</span>
                        @if ($session->llmProvider && $session->llmProvider->config && isset($session->llmProvider->config['model']))
                            | Default Model: <span
                                class="font-medium text-blue-600">{{ $session->llmProvider->config['model'] }}</span>
                        @endif
                    </p>
                @endif
            </div>
        </div>
            <div class="flex space-x-3">
                <button id="clear-chat-btn" 
                    class="clear-chat-btn bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded transition-colors">
                    Очистить чат
                </button>
                {{-- <a href="{{ route('chat.index') }}"
                    class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                    Back to Sessions
                </a> --}}
            </div>
        </div>
    </x-slot>

    <div class="h-full flex flex-col">
        <div class="{{ count($messages) > 0 ? 'max-w-7xl mx-auto sm:px-6 lg:px-8' : 'w-full sm:w-1/2 mx-auto px-4' }} h-full flex flex-col">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg h-full flex flex-col min-w-full">
                <!-- Chat Info Panel -->
                {{-- <div class="bg-gray-50 border-b px-6 py-3">
                    <div class="flex items-center justify-between text-sm text-gray-600">
                        <div class="flex items-center space-x-4">
                            <span class="font-medium">Current Session:</span>
                            <span class="text-blue-600 font-semibold">{{ $session->title }}</span>
                        </div>
                        <div class="flex items-center space-x-4">
                            @if ($session->model)
                                <span class="font-medium">Model:</span>
                                <span class="text-green-600 font-semibold">{{ $session->model }}</span>
                            @elseif($session->llmProvider && $session->llmProvider->config && isset($session->llmProvider->config['model']))
                                <span class="font-medium">Default Model:</span>
                                <span
                                    class="text-green-600 font-semibold">{{ $session->llmProvider->config['model'] }}</span>
                            @endif
                            @if ($session->llmProvider)
                                <span class="font-medium">Provider:</span>
                                <span class="text-purple-600 font-semibold">{{ $session->llmProvider->name }}</span>
                            @endif
                        </div>
                    </div>
                </div> --}}

                <!-- Chat Messages -->
                <div id="chat-messages" class="flex-1 overflow-y-auto pt-3 sm:pt-6 px-3 sm:px-6 space-y-6 pb-32 w-full">
                    @foreach ($messages as $message)
                        <div class="flex {{ $message->role === 'user' ? 'justify-end' : 'justify-start' }}">
                            <div
                                class="max-w-2xl max-w-4/5 lg:max-w-4xl {{ $message->role === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-800' }} rounded-lg shadow-sm">
                                @if ($message->role === 'user')
                                    <div class="px-4 py-3 relative">
                                        <button class="copy-code-btn absolute top-0 right-0 w-6 h-6 bg-blue-500 bg-blue-300 text-white text-xs px-1 py-0.5 rounded transition-colors z-10" onclick="copyCode(this)" data-code="${escapeHtml(code.trim())}">
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7999999999999998" stroke-linecap="round" stroke-linejoin="round" class="tabler-icon tabler-icon-copy "><path d="M7 7m0 2.667a2.667 2.667 0 0 1 2.667 -2.667h8.666a2.667 2.667 0 0 1 2.667 2.667v8.666a2.667 2.667 0 0 1 -2.667 2.667h-8.666a2.667 2.667 0 0 1 -2.667 -2.667z"></path><path d="M4.012 16.737a2.005 2.005 0 0 1 -1.012 -1.737v-10c0 -1.1 .9 -2 2 -2h10c.75 0 1.158 .385 1.5 1"></path></svg>
                            </button>
                                        <div class="text-sm whitespace-pre-wrap">{{ $message->content }}</div>
                                    </div>
                                @else
                                    <div class="px-4 py-3">
                                        <div class="text-sm whitespace-pre-wrap" id="message-{{ $message->id }}">{{ $message->content }}</div>
                                        <div class="text-xs text-gray-500 mt-3 pt-2 border-t border-gray-200 rounded-full sm:rounded-sm">
                                            <span class="inline-flex items-center space-x-4">
                                                <span class="flex items-center">
                                                    <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                        <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                    </svg>
                                                    {{ $message->model_used }}
                                                </span>
                                                <span class="flex items-center">
                                                    <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                        <path
                                                            d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z" />
                                                    </svg>
                                                    {{ $message->tokens_used }} tokens
                                                </span>
                                                <span class="flex items-center">
                                                    <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                        <path
                                                            d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
                                                        <path fill-rule="evenodd"
                                                            d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z"
                                                            clip-rule="evenodd" />
                                                    </svg>
                                                    ${{ number_format($message->cost, 6) }}
                                                </span>
                                                <span class="flex items-center">
                                                    <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                        <path fill-rule="evenodd"
                                                            d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z"
                                                            clip-rule="evenodd" />
                                                    </svg>
                                                    {{ $message->response_time_ms }}ms
                                                </span>
                                            </span>
                                        </div>
                                    </div>
                                @endif
                            </div>
                        </div>
                    @endforeach
                </div>

                <!-- Message Input -->
                <div class="fixed bottom-6 left-1/2 transform -translate-x-1/2 w-full max-w-4xl px-4 z-10">
                    <div class="bg-white border border-gray-300 rounded-2xl shadow-lg p-3">
                        <form id="send-message-form" class="flex space-x-3 items-end">
                            @csrf
                            
                            <textarea id="send-message-input" name="content" placeholder="Type your message..." rows="2"
                                class="flex-1 px-3 py-2 rounded-xl border-gray-100 shadow-sm focus:border-gray-200 focus:ring-gray-200 resize-none bg-gray-50 focus:bg-white transition-colors"
                                style="min-height: 44px; max-height: 120px;"></textarea>
                            <button type="button" 
                                class="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-medium py-3 px-4 mb-1 rounded-xl transition-all duration-200 flex-shrink-0 shadow-lg hover:shadow-xl transform hover:scale-105">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                                </svg>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Подключение Prism.js для подсветки синтаксиса -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-core.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/autoloader/prism-autoloader.min.js"></script> 

    <script>
        // Инициализация после загрузки DOM
        document.addEventListener('DOMContentLoaded', function() {
            // Получаем элементы после загрузки DOM
            const messageForm = document.getElementById('send-message-form');
            const messageInput = document.getElementById('send-message-input');
            const chatMessages = document.getElementById('chat-messages');
            const clearChatBtn = document.getElementById('clear-chat-btn');

            // Проверяем, что все элементы найдены
            if (!messageForm || !messageInput || !chatMessages || !clearChatBtn) {
                console.error('Required elements not found!');
                alert('ОШИБКА: Не найдены необходимые элементы!');
                return;
            }

            
            // Функция для форматирования сообщения
            function formatMessage(content) {
                // Сначала заменяем код-блоки на HTML, сохраняя их содержимое
                const codeBlocks = [];
                content = content.replace(/```(\w+)?\n([\s\S]*?)```/g, function(match, lang, code) {
                    const language = lang || 'text';
                    const placeholder = `__CODE_BLOCK_${codeBlocks.length}__`;
                    codeBlocks.push({
                        placeholder: placeholder,  /* relative style="position: relative;" */
                        html: `<div class="code-block-wrapper relative style="position:relative;"> 
                            <pre class="code-block" data-language="${language}"><code class="language-${language}">${escapeHtml(code.trim())}</code></pre>
                        </div>`
                    });
                    return placeholder;
                });

                // Заменяем инлайн код
                content = content.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');

                // Заменяем переносы строк только вне код-блоков
                content = content.replace(/\n/g, '<br>');

                // Восстанавливаем код-блоки
                codeBlocks.forEach(block => {
                    content = content.replace(block.placeholder, block.html);
                });

                return content;
            }

            // Экранирование HTML
            function escapeHtml(text) {
                const div = document.createElement('div');
                div.textContent = text;
                return div.innerHTML;
            }

            // Функция копирования кода
            function copyCode(button) {
                const code = button.getAttribute('data-code');
                navigator.clipboard.writeText(code).then(function() {
                    // Временно меняем текст кнопки
                    const originalText = button.innerHTML;
                    button.innerHTML = `
                        <svg class="w-3 h-3 mr-1 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                        </svg>
                        Copied!
                    `;
                    button.classList.remove('bg-gray-700', 'hover:bg-gray-600');
                    button.classList.add('bg-green-600');
                    
                    // Возвращаем исходный вид через 2 секунды
                    setTimeout(() => {
                        button.innerHTML = originalText;
                        button.classList.remove('bg-green-600');
                        button.classList.add('bg-gray-700', 'hover:bg-gray-600');
                    }, 2000);
                }).catch(function(err) {
                    console.error('Ошибка копирования:', err);
                    alert('Не удалось скопировать код');
                });
            }

            // Scroll to bottom
            function scrollToBottom() {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }

            // Функция для отправки сообщения
            async function sendMessage(content) {
                
                // Add user message to chat
                const userMessageDiv = document.createElement('div');
                userMessageDiv.className = 'flex justify-end';
                userMessageDiv.innerHTML = `
                    <div class="max-w-2xl lg:max-w-4xl bg-blue-500 text-white rounded-lg shadow-sm">
                        <div class="px-4 py-3">
                            <div class="text-sm whitespace-pre-wrap">${escapeHtml(content)}</div>
                        </div>
                    </div>
                `;
                chatMessages.appendChild(userMessageDiv);

                // Show loading message
                const loadingDiv = document.createElement('div');
                loadingDiv.className = 'flex justify-start';
                loadingDiv.innerHTML = `
                    <div class="max-w-2xl lg:max-w-4xl bg-gray-100 text-gray-800 rounded-lg shadow-sm">
                        <div class="px-4 py-3">
                            <div class="text-sm flex items-center">
                                <svg class="animate-spin -ml-1 mr-3 h-4 w-4 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Thinking...
                            </div>
                        </div>
                    </div>
                `;
                chatMessages.appendChild(loadingDiv);

                scrollToBottom();

                try {
                    const csrfToken = document.querySelector('input[name="_token"]').value;
                    if (!csrfToken) {
                        throw new Error('CSRF token not found');
                    }

                    const response = await fetch('{{ route('chat.send-message', $session) }}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrfToken
                        },
                        body: JSON.stringify({
                            content: content
                        })
                    });

                    const data = await response.json();

                    // Remove loading message
                    chatMessages.removeChild(loadingDiv);

                    if (data.success) {
                        // Add assistant message
                        const assistantMessageDiv = document.createElement('div');
                        assistantMessageDiv.className = 'flex justify-start';
                        assistantMessageDiv.innerHTML = `
                            <div class="max-w-2xl lg:max-w-4xl bg-gray-100 text-gray-800 rounded-lg shadow-sm">
                                <div class="px-4 py-3">
                                    <div class="text-sm whitespace-pre-wrap" id="new-message">${formatMessage(data.message.content)}</div>
                                    <div class="text-xs text-gray-500 mt-3 pt-2 border-t border-gray-200">
                                        <span class="inline-flex items-center space-x-4">
                                            <span class="flex items-center">
                                                <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                    <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                                </svg>
                                                ${data.message.model_used}
                                            </span>
                                            <span class="flex items-center">
                                                <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                    <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/>
                                                </svg>
                                                ${data.message.tokens_used} tokens
                                            </span>
                                            <span class="flex items-center">
                                                <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                    <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z"/>
                                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clip-rule="evenodd"/>
                                                </svg>
                                                $${parseFloat(data.message.cost).toFixed(6)}
                                            </span>
                                            <span class="flex items-center">
                                                <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/>
                                                </svg>
                                                ${data.message.response_time_ms}ms
                                            </span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        `;
                        chatMessages.appendChild(assistantMessageDiv);

                        // Применяем подсветку синтаксиса к новому сообщению
                        const newMessageDiv = document.getElementById('new-message');
                         if (newMessageDiv) {
                            Prism.highlightAllUnder(newMessageDiv);
                        } 

                        // Очищаем поле ввода только после успешного получения ответа
                        messageInput.value = '';
                    } else {
                        // Show error message
                        const errorDiv = document.createElement('div');
                        errorDiv.className = 'flex justify-start';
                        errorDiv.innerHTML = `
                            <div class="max-w-2xl lg:max-w-4xl bg-red-100 text-red-800 rounded-lg shadow-sm">
                                <div class="px-4 py-3">
                                    <div class="text-sm">Error: ${data.error}</div>
                                </div>
                            </div>
                        `;
                        chatMessages.appendChild(errorDiv);
                    }

                    scrollToBottom();
                } catch (error) {
                    // Remove loading message
                    chatMessages.removeChild(loadingDiv);

                    // Show error message
                    const errorDiv = document.createElement('div');
                    errorDiv.className = 'flex justify-start';
                    errorDiv.innerHTML = `
                        <div class="max-w-2xl lg:max-w-4xl bg-red-100 text-red-800 rounded-lg shadow-sm">
                            <div class="px-4 py-3">
                                <div class="text-sm">Error: ${error.message}</div>
                            </div>
                        </div>
                    `;
                    chatMessages.appendChild(errorDiv);
                    scrollToBottom();
                }
            }

            // Функция для обработки отправки
            function handleSendMessage() {
                const content = messageInput.value.trim();
                
                 if (content && content.length > 0) {
                    //alert('Отправляем сообщение: "' + content + '"');
                    sendMessage(content);
                } else {
                    alert('Поле пустое или содержит только пробелы!');
                } 
            }

            // Применяем подсветку синтаксиса к существующим сообщениям
            const assistantMessages = document.querySelectorAll('[id^="message-"]');
             assistantMessages.forEach(messageDiv => {
                messageDiv.innerHTML = formatMessage(messageDiv.innerHTML);
                Prism.highlightAllUnder(messageDiv);
            }); 

            // Добавляем обработчик для нажатия Enter в поле ввода
             messageInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    //alert('Enter нажат!');
                    handleSendMessage();
                }
            }); 

            // Добавляем обработчик для кнопки
            const sendButton = messageForm.querySelector('button[type="button"]');
            if (sendButton) {
                sendButton.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    //alert('Кнопка Send нажата!');
                    handleSendMessage();
                });
            }

            // Добавляем обработчик для формы (резервный)
            /* messageForm.addEventListener('submit', function(e) {
                e.preventDefault();
                //alert('Форма отправлена!');
                handleSendMessage();
            }); */

            // Добавляем обработчик для кнопки "Очистить чат"
            if (clearChatBtn) {
                clearChatBtn.addEventListener('click', function() {
                    if (confirm('Вы уверены, что хотите очистить весь чат?')) {
                        clearChat();
                    }
                });
            }

            // Функция для очистки чата
            async function clearChat() {
                try {
                    const csrfToken = document.querySelector('input[name="_token"]').value;
                    if (!csrfToken) {
                        throw new Error('CSRF token not found');
                    }

                    const response = await fetch('{{ route('chat.clear', $session) }}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrfToken
                        }
                    });

                    const data = await response.json();

                    if (data.success) {
                        // Очищаем сообщения в чате
                        chatMessages.innerHTML = '';
                        // Очищаем поле ввода
                        messageInput.value = '';
                        alert('Чат очищен!');
                    } else {
                        alert('Ошибка при очистке чата: ' + data.error);
                    }
                } catch (error) {
                    console.error('Ошибка очистки чата:', error);
                    alert('Ошибка при очистке чата: ' + error.message);
                }
            }

            scrollToBottom();
        });
    </script>

    <style>
        /* Стили для код-блоков */
        .code-block {
            background: #1e1e1e;
            border-radius: 12px;
            margin: 1.5rem 0;
            position: relative;
            overflow: hidden;
            border: 1px solid #333;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .code-block::before {
            content: attr(data-language);
            position: absolute;
            top: 0;
            right: 0;
            background: #333;
            color: #fff;
            padding: 4px 12px;
            font-size: 0.75rem;
            font-weight: 500;
            border-radius: 0 12px 0 8px;
            z-index: 1;
        }

        .code-block code {
            display: block;
            padding: 1.5rem;
            overflow-x: auto;
            overflow-y: auto;
            font-family: 'Fira Code', 'Monaco', 'Consolas', 'Courier New', monospace;
            font-size: 0.875rem;
            line-height: 1.6;
            color: #e5e7eb;
            white-space: pre-wrap;
            word-wrap: break-word;
            min-height: 60px;
        }

        .code-block code::-webkit-scrollbar {
            height: 8px;
            width: 8px;
        }

        .code-block code::-webkit-scrollbar-track {
            background: #2d2d2d;
            border-radius: 4px;
        }

        .code-block code::-webkit-scrollbar-thumb {
            background: #555;
            border-radius: 4px;
        }

        .code-block code::-webkit-scrollbar-thumb:hover {
            background: #777;
        }

        .inline-code {
            background: #f3f4f6;
            padding: 3px 6px;
            border-radius: 6px;
            font-family: 'Fira Code', 'Monaco', 'Consolas', 'Courier New', monospace;
            font-size: 0.875em;
            color: #374151;
            border: 1px solid #e5e7eb;
        }

        /* Улучшенные стили для сообщений */
        .chat-message {
            transition: all 0.2s ease-in-out;
        }

        .chat-message:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        /* Анимация для загрузки */
        @keyframes pulse {
            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0.5;
            }
        }

        .animate-pulse {
            animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
    </style>
</x-app-layout>
