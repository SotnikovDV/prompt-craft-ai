<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Chat Sessions') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <!-- New Chat Button -->
                    <div class="mb-6">
                        <button onclick="openNewChatModal()" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            New Chat
                        </button>
                    </div>

                    <!-- Chat Sessions List -->
                    <div class="space-y-4">
                        @forelse($sessions as $session)
                            <div class="border rounded-lg p-4 hover:bg-gray-50">
                                <div class="flex justify-between items-center">
                                    <div>
                                        <h3 class="text-lg font-semibold">{{ $session->title }}</h3>
                                        <p class="text-sm text-gray-600">
                                            Provider: {{ $session->llmProvider->name }}
                                            @if($session->model)
                                                | Model: {{ $session->model }}
                                            @endif
                                        </p>
                                        <p class="text-xs text-gray-500">
                                            Last activity: {{ $session->last_activity ? $session->last_activity->diffForHumans() : 'Never' }}
                                        </p>
                                    </div>
                                    <div class="flex space-x-2">
                                        <a href="{{ route('chat.show', $session) }}" 
                                           class="bg-green-500 hover:bg-green-700 text-white text-sm py-1 px-3 rounded">
                                            Open
                                        </a>
                                        <form action="{{ route('chat.delete-session', $session) }}" method="POST" class="inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" 
                                                    onclick="return confirm('Are you sure?')"
                                                    class="bg-red-500 hover:bg-red-700 text-white text-sm py-1 px-3 rounded">
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @empty
                            <div class="text-center py-8">
                                <p class="text-gray-500">No chat sessions yet. Start a new chat!</p>
                            </div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- New Chat Modal -->
    <div id="newChatModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden">
        <div class="flex items-center justify-center min-h-screen">
            <div class="bg-white rounded-lg p-6 w-full max-w-md">
                <h3 class="text-lg font-semibold mb-4">New Chat Session</h3>
                <form action="{{ route('chat.create-session') }}" method="POST">
                    @csrf
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700">Title</label>
                        <input type="text" name="title" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700">LLM Provider</label>
                        <div class="custom-select mt-1">
                            <select name="llm_provider_id" id="provider-select" onchange="updateModelOptions()">
                                @foreach($providers as $provider)
                                    <option value="{{ $provider->id }}" 
                                            data-models="{{ is_array($provider->models) ? implode(',', $provider->models) : $provider->models }}"
                                            data-default-model="{{ $provider->config['model'] ?? '' }}">
                                        {{ $provider->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700">Model</label>
                        <div class="custom-select mt-1">
                            <select name="model" id="model-select">
                                <option value="">Use default model</option>
                            </select>
                        </div>
                        <p class="mt-1 text-xs text-gray-500">Select a specific model or use the default</p>
                    </div>
                    <div class="flex justify-end space-x-2">
                        <button type="button" onclick="closeNewChatModal()" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded">
                            Cancel
                        </button>
                        <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            Create
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function openNewChatModal() {
            document.getElementById('newChatModal').classList.remove('hidden');
            // Инициализируем модели при открытии модального окна
            updateModelOptions();
        }

        function closeNewChatModal() {
            document.getElementById('newChatModal').classList.add('hidden');
        }

        function updateModelOptions() {
            const providerSelect = document.getElementById('provider-select');
            const modelSelect = document.getElementById('model-select');
            const selectedOption = providerSelect.options[providerSelect.selectedIndex];
            
            // Очищаем текущие опции
            modelSelect.innerHTML = '<option value="">Use default model</option>';
            
            if (selectedOption) {
                const models = selectedOption.getAttribute('data-models');
                const defaultModel = selectedOption.getAttribute('data-default-model');
                
                if (models) {
                    const modelList = models.split(',').map(model => model.trim()).filter(model => model);
                    
                    modelList.forEach(model => {
                        const option = document.createElement('option');
                        option.value = model;
                        option.textContent = model;
                        
                        // Выделяем модель по умолчанию
                        if (model === defaultModel) {
                            option.textContent += ' (default)';
                        }
                        
                        modelSelect.appendChild(option);
                    });
                }
                
                // Показываем информацию о модели по умолчанию
                if (defaultModel) {
                    const defaultOption = modelSelect.querySelector('option[value=""]');
                    defaultOption.textContent = `Use default model (${defaultModel})`;
                }
            }
        }
    </script>
</x-app-layout>
