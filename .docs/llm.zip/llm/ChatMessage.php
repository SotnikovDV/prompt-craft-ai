<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChatMessage extends Model
{
    use HasFactory;

    protected $fillable = [
        'chat_session_id',
        'role',
        'content',
        'metadata',
        'model_used',
        'tokens_used',
        'cost',
        'response_time_ms',
        'is_hidden',
    ];

    protected $casts = [
        'metadata' => 'array',
        'cost' => 'decimal:6',
        'is_hidden' => 'boolean',
    ];

    public function chatSession()
    {
        return $this->belongsTo(ChatSession::class);
    }
}
