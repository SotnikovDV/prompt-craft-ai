<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Edit LLM Provider') }}: {{ $provider->name }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form action="{{ route('providers.update', $provider) }}" method="POST">
                        @csrf
                        @method('PUT')
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Basic Information -->
                            <div class="space-y-4">
                                <h3 class="text-lg font-semibold text-gray-900">Basic Information</h3>
                                
                                <div>
                                    <label for="name" class="block text-sm font-medium text-gray-700">Provider Name</label>
                                    <input type="text" name="name" id="name" value="{{ old('name', $provider->name) }}" required
                                           class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                    @error('name')
                                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>

                                <div>
                                    <label for="type" class="block text-sm font-medium text-gray-700">Type</label>
                                    <div class="custom-select mt-1 {{ $errors->has('type') ? 'error' : '' }}">
                                        <select name="type" id="type" required>
                                            <option value="">Select Type</option>
                                            <option value="external" {{ old('type', $provider->type) == 'external' ? 'selected' : '' }}>External API</option>
                                            <option value="local" {{ old('type', $provider->type) == 'local' ? 'selected' : '' }}>Local Model</option>
                                        </select>
                                    </div>
                                    @error('type')
                                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>

                                <div>
                                    <label for="api_endpoint" class="block text-sm font-medium text-gray-700">API Endpoint</label>
                                    <input type="url" name="api_endpoint" id="api_endpoint" value="{{ old('api_endpoint', $provider->api_endpoint) }}"
                                           placeholder="https://api.openai.com/v1"
                                           class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                    @error('api_endpoint')
                                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>

                                <div>
                                    <label for="api_key" class="block text-sm font-medium text-gray-700">API Key</label>
                                    <input type="password" name="api_key" id="api_key" value="{{ old('api_key', $provider->api_key) }}"
                                           placeholder="Leave blank to keep current key"
                                           class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                    <p class="mt-1 text-xs text-gray-500">Leave blank to keep the current API key</p>
                                    @error('api_key')
                                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>

                            <!-- Configuration -->
                            <div class="space-y-4">
                                <h3 class="text-lg font-semibold text-gray-900">Configuration</h3>
                                
                                <div>
                                    <label for="rate_limit" class="block text-sm font-medium text-gray-700">Rate Limit (requests/min)</label>
                                    <input type="number" name="rate_limit" id="rate_limit" value="{{ old('rate_limit', $provider->rate_limit) }}"
                                           min="1" max="1000"
                                           class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                    @error('rate_limit')
                                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>

                                <div>
                                    <label for="timeout" class="block text-sm font-medium text-gray-700">Request Timeout (seconds)</label>
                                    <input type="number" name="timeout" id="timeout" value="{{ old('timeout', $provider->timeout ?? 120) }}"
                                           min="30" max="600"
                                           class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                    <p class="mt-1 text-xs text-gray-500">Recommended: 120s for external APIs, 180s for local models</p>
                                    @error('timeout')
                                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>

                                <div>
                                    <label class="flex items-center">
                                        <input type="checkbox" name="is_active" value="1" {{ old('is_active', $provider->is_active) ? 'checked' : '' }}
                                               class="rounded border-gray-300 text-blue-600 shadow-sm focus:ring-blue-500">
                                        <span class="ml-2 text-sm text-gray-700">Active Provider</span>
                                    </label>
                                </div>

                                <div>
                                    <label for="models" class="block text-sm font-medium text-gray-700">Available Models (comma-separated)</label>
                                    <textarea name="models" id="models" rows="3" placeholder="gpt-4, gpt-3.5-turbo, claude-3"
                                              class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">{{ old('models', is_array($provider->models) ? implode(', ', $provider->models) : $provider->models) }}</textarea>
                                    <p class="mt-1 text-xs text-gray-500">Enter model names separated by commas</p>
                                    @error('models')
                                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="mt-6 flex justify-end space-x-3">
                            <a href="{{ route('providers.index') }}" 
                               class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded">
                                Cancel
                            </a>
                            <button type="submit" 
                                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                Update Provider
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
