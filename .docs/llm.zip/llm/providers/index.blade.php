<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('LLM Providers') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Success Messages -->
            @if(session('success'))
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
                    {{ session('success') }}
                </div>
            @endif
            
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <!-- New Provider Button -->
                    <div class="mb-6">
                        <a href="{{ route('providers.create') }}" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            Add Provider
                        </a>
                    </div>

                    <!-- Providers List -->
                    <div class="space-y-4">
                        @forelse($providers as $provider)
                            <div class="border rounded-lg p-4 hover:bg-gray-50">
                                <div class="flex justify-between items-center">
                                    <div>
                                        <h3 class="text-lg font-semibold">{{ $provider->name }}</h3>
                                        <p class="text-sm text-gray-600">
                                            Type: {{ ucfirst($provider->type) }}
                                            @if($provider->api_endpoint)
                                                | Endpoint: {{ $provider->api_endpoint }}
                                            @endif
                                        </p>
                                        <p class="text-xs text-gray-500">
                                            Status: <span class="font-semibold {{ $provider->is_active ? 'text-green-600' : 'text-red-600' }}">{{ $provider->is_active ? 'Active' : 'Inactive' }}</span>
                                            @if($provider->rate_limit)
                                                | Rate Limit: {{ $provider->rate_limit }}/min
                                            @endif
                                            @if($provider->timeout)
                                                | Timeout: {{ $provider->timeout }}s
                                            @endif
                                        </p>
                                    </div>
                                    <div class="flex space-x-2">
                                        <a href="{{ route('providers.edit', $provider) }}" 
                                           class="bg-blue-500 hover:bg-blue-700 text-white text-sm py-1 px-3 rounded">
                                            Edit
                                        </a>
                                        <form action="{{ route('providers.destroy', $provider) }}" method="POST" class="inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" 
                                                    onclick="return confirm('Are you sure?')"
                                                    class="bg-red-500 hover:bg-red-700 text-white text-sm py-1 px-3 rounded">
                                                Delete
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @empty
                            <div class="text-center py-8">
                                <p class="text-gray-500">No LLM providers configured yet. Add your first provider!</p>
                            </div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

